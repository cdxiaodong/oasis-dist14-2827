import type { UserSession } from "../common/user-session";
import { SessionsService } from "./sessions.service";
declare class CreateSessionDto {
    storeId: string;
    roomId: string;
    scriptId: string;
    hostId: string;
    assistantId?: string;
    npcId?: string;
    assistantIds?: string[];
    npcIds?: string[];
    assistantAssignments?: Array<{
        userId: string;
        feeTier?: string;
        feeCents?: number;
    }>;
    npcAssignments?: Array<{
        userId: string;
        feeTier?: string;
        feeCents?: number;
    }>;
    allowPersonnelOverlap?: boolean;
    startAt: string;
    expectedEndAt: string;
    notes?: string;
}
declare class UpdateSessionDto {
    roomId?: string;
    scriptId?: string;
    hostId?: string;
    assistantAssignments?: Array<{
        userId: string;
        feeTier?: string;
        feeCents?: number;
    }>;
    npcAssignments?: Array<{
        userId: string;
        feeTier?: string;
        feeCents?: number;
    }>;
    startAt?: string;
    expectedEndAt?: string;
    notes?: string;
    joinEnabled?: boolean;
}
declare class AddPlayerDto {
    name?: string;
    phone?: string;
    type?: string;
    paymentMethod?: string;
    amountCents?: number;
    discountCents?: number;
    activity?: string;
    proofUrl?: string;
    proofUrls?: string[];
    memberId?: string;
    remark?: string;
}
declare class PaymentDto {
    name?: string;
    phone?: string;
    type?: string;
    paymentMethod: string;
    amountCents: number;
    discountCents?: number;
    activity?: string;
    proofUrl?: string;
    proofUrls?: string[];
    memberId?: string;
    remark?: string;
}
declare class UpdatePlayerDto {
    name?: string;
    phone?: string;
    type?: string;
    remark?: string;
}
declare class ReasonDto {
    reason: string;
}
declare class RefundDto extends ReasonDto {
    amountCents: number;
}
declare class AssignmentResponseDto {
    status: string;
    note?: string;
}
declare class MaterialDto {
    phase: string;
    label: string;
    imageUrl: string;
    note?: string;
}
declare class DesignationDto {
    staffId: string;
    staffRole: string;
    proofUrl: string;
    proofUrls?: string[];
    note?: string;
}
declare class DesignationStatusDto {
    status: string;
}
declare class TransitionDto {
    action: string;
    note?: string;
}
export declare class SessionsController {
    private readonly sessions;
    constructor(sessions: SessionsService);
    list(user: UserSession, storeId?: string, state?: string): Promise<({
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    })[]>;
    one(user: UserSession, id: string): Promise<{
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    create(user: UserSession, dto: CreateSessionDto): Promise<{
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    update(user: UserSession, id: string, dto: UpdateSessionDto): Promise<{
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    addPlayer(user: UserSession, id: string, dto: AddPlayerDto): Promise<{
        member: {
            id: string;
            name: string;
            phone: string;
            balanceCents: number;
            tier: string;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string | null;
        status: string;
        type: string;
        paymentMethod: string | null;
        amountCents: number;
        discountCents: number;
        activity: string | null;
        proofUrl: string | null;
        remark: string | null;
        refundedCents: number;
        removedAt: Date | null;
        removedReason: string | null;
        guestOpenId: string | null;
        memberId: string | null;
        sessionId: string;
    }>;
    payment(user: UserSession, id: string, playerId: string, dto: PaymentDto): Promise<{
        member: {
            id: string;
            name: string;
            phone: string;
            balanceCents: number;
            tier: string;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string | null;
        status: string;
        type: string;
        paymentMethod: string | null;
        amountCents: number;
        discountCents: number;
        activity: string | null;
        proofUrl: string | null;
        remark: string | null;
        refundedCents: number;
        removedAt: Date | null;
        removedReason: string | null;
        guestOpenId: string | null;
        memberId: string | null;
        sessionId: string;
    }>;
    updatePlayer(user: UserSession, id: string, playerId: string, dto: UpdatePlayerDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string | null;
        status: string;
        type: string;
        paymentMethod: string | null;
        amountCents: number;
        discountCents: number;
        activity: string | null;
        proofUrl: string | null;
        remark: string | null;
        refundedCents: number;
        removedAt: Date | null;
        removedReason: string | null;
        guestOpenId: string | null;
        memberId: string | null;
        sessionId: string;
    }>;
    removePlayer(user: UserSession, id: string, playerId: string, dto: ReasonDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string | null;
        status: string;
        type: string;
        paymentMethod: string | null;
        amountCents: number;
        discountCents: number;
        activity: string | null;
        proofUrl: string | null;
        remark: string | null;
        refundedCents: number;
        removedAt: Date | null;
        removedReason: string | null;
        guestOpenId: string | null;
        memberId: string | null;
        sessionId: string;
    }>;
    refundPlayer(user: UserSession, id: string, playerId: string, dto: RefundDto): Promise<{
        member: {
            id: string;
            name: string;
            phone: string;
            balanceCents: number;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string | null;
        status: string;
        type: string;
        paymentMethod: string | null;
        amountCents: number;
        discountCents: number;
        activity: string | null;
        proofUrl: string | null;
        remark: string | null;
        refundedCents: number;
        removedAt: Date | null;
        removedReason: string | null;
        guestOpenId: string | null;
        memberId: string | null;
        sessionId: string;
    }>;
    respondAssignment(user: UserSession, id: string, assignmentId: string, dto: AssignmentResponseDto): Promise<{
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        role: string;
        status: string;
        sessionId: string;
        note: string | null;
        feeTier: string | null;
        feeCents: number;
        shiftStartAt: Date | null;
        shiftEndAt: Date | null;
        respondedAt: Date | null;
        userId: string;
    }>;
    material(user: UserSession, id: string, dto: MaterialDto): Promise<{
        id: string;
        createdAt: Date;
        sessionId: string;
        note: string | null;
        phase: string;
        label: string;
        imageUrl: string;
    }>;
    designate(user: UserSession, id: string, dto: DesignationDto): Promise<{
        staff: {
            id: string;
            name: string;
            role: string;
        };
        createdBy: {
            id: string;
            name: string;
        };
    } & {
        id: string;
        createdAt: Date;
        proofUrl: string;
        sessionId: string;
        note: string | null;
        staffId: string;
        staffRole: string;
        createdById: string;
    }>;
    designationStatus(user: UserSession, id: string, dto: DesignationStatusDto): Promise<{
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    transition(user: UserSession, id: string, dto: TransitionDto): Promise<{
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
}
export {};
