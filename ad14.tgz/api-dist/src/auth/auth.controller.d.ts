import { AuthService } from "./auth.service";
import type { UserSession } from "../common/user-session";
declare class LoginDto {
    username: string;
    password: string;
    legalVersion?: string;
    privacyAccepted?: boolean;
}
declare class ChangePasswordDto {
    oldPassword: string;
    newPassword: string;
}
declare class WechatLoginDto {
    loginCode: string;
    phoneCode: string;
    legalVersion?: string;
    privacyAccepted?: boolean;
}
declare class WechatSessionDto {
    loginCode: string;
    legalVersion?: string;
    privacyAccepted?: boolean;
}
export declare class AuthController {
    private readonly auth;
    constructor(auth: AuthService);
    login(dto: LoginDto): Promise<{
        accessToken: string;
        user: {
            id: string;
            username: string;
            name: string;
            role: string;
            storeId: string | null;
            store: unknown;
            mustChangePassword: boolean;
        };
    }>;
    wechatLogin(dto: WechatLoginDto): Promise<{
        accessToken: string;
        user: {
            id: string;
            username: string;
            name: string;
            role: string;
            storeId: string | null;
            store: unknown;
            mustChangePassword: boolean;
        };
    }>;
    wechatSession(dto: WechatSessionDto): Promise<{
        accessToken: string;
        user: {
            id: string;
            username: string;
            name: string;
            role: string;
            storeId: string | null;
            store: unknown;
            mustChangePassword: boolean;
        };
    }>;
    me(user: UserSession): UserSession;
    changePassword(user: UserSession, dto: ChangePasswordDto): Promise<{
        success: boolean;
    }>;
}
export {};
