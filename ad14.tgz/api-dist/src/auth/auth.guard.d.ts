import { CanActivate, ExecutionContext } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { Reflector } from "@nestjs/core";
import { PrismaService } from "../prisma/prisma.service";
export declare const SKIP_PASSWORD_CHECK = "skipPasswordCheck";
export declare const SkipPasswordCheck: () => import("@nestjs/common").CustomDecorator<string>;
export declare class AuthGuard implements CanActivate {
    private readonly jwt;
    private readonly reflector;
    private readonly prisma;
    constructor(jwt: JwtService, reflector: Reflector, prisma: PrismaService);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
