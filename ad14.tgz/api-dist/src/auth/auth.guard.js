"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthGuard = exports.SkipPasswordCheck = exports.SKIP_PASSWORD_CHECK = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const core_1 = require("@nestjs/core");
const common_2 = require("@nestjs/common");
const public_decorator_1 = require("./public.decorator");
const prisma_service_1 = require("../prisma/prisma.service");
exports.SKIP_PASSWORD_CHECK = "skipPasswordCheck";
const SkipPasswordCheck = () => (0, common_2.SetMetadata)(exports.SKIP_PASSWORD_CHECK, true);
exports.SkipPasswordCheck = SkipPasswordCheck;
let AuthGuard = class AuthGuard {
    jwt;
    reflector;
    prisma;
    constructor(jwt, reflector, prisma) {
        this.jwt = jwt;
        this.reflector = reflector;
        this.prisma = prisma;
    }
    async canActivate(context) {
        if (this.reflector.getAllAndOverride(public_decorator_1.IS_PUBLIC_KEY, [context.getHandler(), context.getClass()])) {
            return true;
        }
        const request = context.switchToHttp().getRequest();
        const authorization = request.headers.authorization;
        const queryToken = request.method === "GET" && String(request.originalUrl || "").startsWith("/api/uploads/files/") ? request.query?.access_token : undefined;
        const token = authorization?.startsWith("Bearer ") ? authorization.slice(7) : typeof queryToken === "string" ? queryToken : undefined;
        if (!token)
            throw new common_1.UnauthorizedException("请先登录");
        let payload;
        try {
            payload = await this.jwt.verifyAsync(token);
        }
        catch {
            throw new common_1.UnauthorizedException("登录已过期，请重新登录");
        }
        const current = await this.prisma.user.findUnique({
            where: { id: payload.id },
            select: { id: true, username: true, name: true, role: true, storeId: true, active: true, mustChangePassword: true },
        });
        if (!current || !current.active)
            throw new common_1.UnauthorizedException("账号已停用或不存在");
        const skipPwCheck = this.reflector.getAllAndOverride(exports.SKIP_PASSWORD_CHECK, [context.getHandler(), context.getClass()]);
        if (current.mustChangePassword && !skipPwCheck) {
            throw new common_1.UnauthorizedException("首次登录请先修改密码");
        }
        request.user = {
            id: current.id,
            username: current.username,
            name: current.name,
            role: current.role,
            storeId: current.storeId,
            mustChangePassword: current.mustChangePassword,
        };
        return true;
    }
};
exports.AuthGuard = AuthGuard;
exports.AuthGuard = AuthGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [jwt_1.JwtService,
        core_1.Reflector,
        prisma_service_1.PrismaService])
], AuthGuard);
//# sourceMappingURL=auth.guard.js.map