"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const bcryptjs_1 = require("bcryptjs");
const prisma_service_1 = require("../prisma/prisma.service");
const wechat_auth_service_1 = require("./wechat-auth.service");
let AuthService = class AuthService {
    prisma;
    jwt;
    wechat;
    constructor(prisma, jwt, wechat) {
        this.prisma = prisma;
        this.jwt = jwt;
        this.wechat = wechat;
    }
    async login(username, password, legalVersion, privacyAccepted) {
        const user = await this.prisma.user.findUnique({ where: { username }, include: { store: true } });
        if (!user || !user.active || !(await (0, bcryptjs_1.compare)(password, user.passwordHash))) {
            throw new common_1.UnauthorizedException("账号或密码错误");
        }
        await this.recordLegalAcceptance(user.id, user.legalVersion, legalVersion, privacyAccepted);
        return this.issueToken(user);
    }
    async wechatLogin(loginCode, phoneCode, legalVersion, privacyAccepted) {
        const identity = await this.wechat.authenticate(loginCode, phoneCode);
        const phone = this.normalizePhone(identity.phone);
        const user = await this.prisma.$transaction(async (tx) => {
            const [byOpenId, phoneMatches] = await Promise.all([
                tx.user.findUnique({ where: { wechatOpenId: identity.openId }, include: { store: true } }),
                tx.user.findMany({ where: { phone }, include: { store: true }, take: 2 }),
            ]);
            if (phoneMatches.length > 1)
                throw new common_1.ConflictException("该手机号关联了多个员工账号，请联系管理员处理");
            const byPhone = phoneMatches[0];
            if (byOpenId && byPhone && byOpenId.id !== byPhone.id) {
                throw new common_1.ConflictException("当前微信与手机号分别绑定了不同员工账号，请联系管理员处理");
            }
            const matched = byOpenId ?? byPhone;
            if (!matched)
                throw new common_1.UnauthorizedException("该手机号尚未开通员工账号，请联系店长添加");
            if (!matched.active)
                throw new common_1.UnauthorizedException("员工账号已停用，请联系店长");
            if (matched.phone !== phone)
                throw new common_1.UnauthorizedException("微信授权手机号与员工资料不一致，请联系店长更新");
            if (matched.wechatOpenId && matched.wechatOpenId !== identity.openId) {
                throw new common_1.ConflictException("该员工账号已绑定其他微信，请联系管理员解绑");
            }
            const firstBinding = !matched.wechatOpenId;
            const updated = await tx.user.update({
                where: { id: matched.id },
                data: {
                    wechatOpenId: identity.openId,
                    wechatUnionId: identity.unionId ?? matched.wechatUnionId,
                    lastWechatLoginAt: new Date(),
                    mustChangePassword: false,
                    ...(privacyAccepted && legalVersion ? { legalVersion, legalAcceptedAt: new Date() } : {}),
                },
                include: { store: true },
            });
            if (firstBinding) {
                await tx.auditLog.create({
                    data: { userId: updated.id, action: "BIND_WECHAT", entityType: "User", entityId: updated.id },
                });
            }
            if (privacyAccepted && legalVersion && matched.legalVersion !== legalVersion) {
                await tx.auditLog.create({
                    data: { userId: updated.id, action: "ACCEPT_LEGAL_TERMS", entityType: "User", entityId: updated.id, payload: JSON.stringify({ legalVersion }) },
                });
            }
            return updated;
        });
        return this.issueToken(user);
    }
    async wechatSession(loginCode, legalVersion, privacyAccepted) {
        const identity = await this.wechat.getSession(loginCode);
        const user = await this.prisma.user.findUnique({ where: { wechatOpenId: identity.openId }, include: { store: true } });
        if (!user)
            throw new common_1.UnauthorizedException("请先使用手机号完成首次登录");
        if (!user.active)
            throw new common_1.UnauthorizedException("员工账号已停用，请联系店长");
        const updated = await this.prisma.user.update({
            where: { id: user.id },
            data: { lastWechatLoginAt: new Date(), wechatUnionId: identity.unionId ?? user.wechatUnionId, ...(privacyAccepted && legalVersion ? { legalVersion, legalAcceptedAt: new Date() } : {}) },
            include: { store: true },
        });
        await this.recordLegalAcceptance(updated.id, user.legalVersion, legalVersion, privacyAccepted, false);
        return this.issueToken(updated);
    }
    async changePassword(userId, oldPassword, newPassword) {
        const user = await this.prisma.user.findUnique({ where: { id: userId } });
        if (!user || !(await (0, bcryptjs_1.compare)(oldPassword, user.passwordHash)))
            throw new common_1.BadRequestException("原密码不正确");
        if (await (0, bcryptjs_1.compare)(newPassword, user.passwordHash))
            throw new common_1.BadRequestException("新密码不能与原密码相同");
        await this.prisma.user.update({ where: { id: userId }, data: { passwordHash: await (0, bcryptjs_1.hash)(newPassword, 10), mustChangePassword: false } });
        await this.prisma.auditLog.create({ data: { userId, action: "CHANGE_PASSWORD", entityType: "User", entityId: userId } });
        return { success: true };
    }
    normalizePhone(value) {
        const digits = value.replace(/\D/g, "");
        const phone = digits.startsWith("86") && digits.length === 13 ? digits.slice(2) : digits;
        if (!/^1\d{10}$/.test(phone))
            throw new common_1.UnauthorizedException("微信授权手机号格式异常");
        return phone;
    }
    async recordLegalAcceptance(userId, previousVersion, legalVersion, privacyAccepted, updateUser = true) {
        if (!privacyAccepted || !legalVersion || previousVersion === legalVersion)
            return;
        if (updateUser)
            await this.prisma.user.update({ where: { id: userId }, data: { legalVersion, legalAcceptedAt: new Date() } });
        await this.prisma.auditLog.create({ data: { userId, action: "ACCEPT_LEGAL_TERMS", entityType: "User", entityId: userId, payload: JSON.stringify({ legalVersion }) } });
    }
    async issueToken(user) {
        const profile = {
            id: user.id,
            username: user.username,
            name: user.name,
            role: user.role,
            storeId: user.storeId,
            store: user.store,
            mustChangePassword: user.mustChangePassword,
        };
        return { accessToken: await this.jwt.signAsync(profile), user: profile };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        jwt_1.JwtService,
        wechat_auth_service_1.WechatAuthService])
], AuthService);
//# sourceMappingURL=auth.service.js.map