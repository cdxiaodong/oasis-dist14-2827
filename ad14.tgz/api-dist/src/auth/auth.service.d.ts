import { JwtService } from "@nestjs/jwt";
import { PrismaService } from "../prisma/prisma.service";
import { WechatAuthService } from "./wechat-auth.service";
export declare class AuthService {
    private readonly prisma;
    private readonly jwt;
    private readonly wechat;
    constructor(prisma: PrismaService, jwt: JwtService, wechat: WechatAuthService);
    login(username: string, password: string, legalVersion?: string, privacyAccepted?: boolean): Promise<{
        accessToken: string;
        user: {
            id: string;
            username: string;
            name: string;
            role: string;
            storeId: string | null;
            store: unknown;
            mustChangePassword: boolean;
        };
    }>;
    wechatLogin(loginCode: string, phoneCode: string, legalVersion?: string, privacyAccepted?: boolean): Promise<{
        accessToken: string;
        user: {
            id: string;
            username: string;
            name: string;
            role: string;
            storeId: string | null;
            store: unknown;
            mustChangePassword: boolean;
        };
    }>;
    wechatSession(loginCode: string, legalVersion?: string, privacyAccepted?: boolean): Promise<{
        accessToken: string;
        user: {
            id: string;
            username: string;
            name: string;
            role: string;
            storeId: string | null;
            store: unknown;
            mustChangePassword: boolean;
        };
    }>;
    changePassword(userId: string, oldPassword: string, newPassword: string): Promise<{
        success: boolean;
    }>;
    private normalizePhone;
    private recordLegalAcceptance;
    private issueToken;
}
