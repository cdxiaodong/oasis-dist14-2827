import { type UserSession } from "../common/user-session";
import { PrismaService } from "../prisma/prisma.service";
export declare class SystemService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private static readonly DEFAULT_PERMISSIONS;
    private static readonly ALL_PERMISSIONS;
    permissions(_user: UserSession): Promise<Record<string, string | boolean>[]>;
    savePermissions(user: UserSession, items: Array<{
        role: string;
        permission: string;
        allowed: boolean;
    }>): Promise<{
        success: boolean;
    }>;
    effectivePermissions(): Promise<Record<string, string[]>>;
    status(user: UserSession): Promise<{
        status: string;
        database: string;
        environment: string;
        startedAt: string;
        uptimeSeconds: number;
        counts: {
            stores: number;
            users: number;
            sessions: number;
            auditLogs: number;
        };
    }>;
    auditLogs(user: UserSession, action?: string): import("@prisma/client").Prisma.PrismaPromise<({
        user: {
            id: string;
            storeId: string | null;
            store: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            } | null;
            name: string;
            role: string;
        };
    } & {
        id: string;
        createdAt: Date;
        action: string;
        entityType: string;
        entityId: string;
        payload: string | null;
        userId: string;
    })[]>;
    transfers(user: UserSession): import("@prisma/client").Prisma.PrismaPromise<({
        user: {
            id: string;
            username: string;
            name: string;
        };
        operator: {
            id: string;
            name: string;
        };
        fromStore: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
        toStore: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        operatorId: string;
        userId: string;
        reason: string | null;
        fromStoreId: string | null;
        toStoreId: string | null;
    })[]>;
    transferUser(operator: UserSession, userId: string, storeId: string, reason?: string): Promise<{
        user: {
            id: string;
            storeId: string | null;
            store: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            } | null;
            username: string;
            name: string;
            role: string;
        };
        transfer: {
            fromStore: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            } | null;
            toStore: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            } | null;
        } & {
            id: string;
            createdAt: Date;
            operatorId: string;
            userId: string;
            reason: string | null;
            fromStoreId: string | null;
            toStoreId: string | null;
        };
    }>;
    resetPassword(operator: UserSession, userId: string, newPassword: string): Promise<{
        success: boolean;
    }>;
}
