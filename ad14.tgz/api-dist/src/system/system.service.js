"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var SystemService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemService = void 0;
const common_1 = require("@nestjs/common");
const bcryptjs_1 = require("bcryptjs");
const user_session_1 = require("../common/user-session");
const prisma_service_1 = require("../prisma/prisma.service");
let SystemService = class SystemService {
    static { SystemService_1 = this; }
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    static DEFAULT_PERMISSIONS = {
        HEADQUARTERS: ["dashboard", "revenue-details", "sessions", "create-session", "members", "catalog", "operations", "business", "workforce", "staff-development", "customer-service", "system"],
        FINANCE: ["dashboard", "revenue-details", "sessions", "members", "operations", "business", "workforce", "staff-development", "system"],
        MANAGER: ["dashboard", "revenue-details", "sessions", "create-session", "members", "catalog", "operations", "business", "workforce", "staff-development", "customer-service", "system"],
        CUSTOMER_SERVICE: ["customer-service"],
        DM: ["sessions", "create-session", "members", "my-attendance", "portal"],
        ASSISTANT: ["sessions", "create-session", "members", "my-attendance", "portal"],
        NPC: ["sessions", "create-session", "members", "my-attendance", "portal"],
        STAFF: ["sessions", "create-session", "members", "my-attendance", "portal"],
    };
    static ALL_PERMISSIONS = ["dashboard", "revenue-details", "sessions", "create-session", "members", "my-attendance", "portal", "catalog", "operations", "business", "workforce", "staff-development", "customer-service", "system"];
    async permissions(_user) {
        const overrides = await this.prisma.permissionOverride.findMany();
        const overrideMap = new Map(overrides.map((item) => [`${item.role}:${item.permission}`, item.allowed]));
        return SystemService_1.ALL_PERMISSIONS.map((permission) => {
            const row = { permission };
            for (const role of Object.keys(SystemService_1.DEFAULT_PERMISSIONS)) {
                const key = `${role}:${permission}`;
                row[role] = overrideMap.has(key) ? Boolean(overrideMap.get(key)) : (SystemService_1.DEFAULT_PERMISSIONS[role] || []).includes(permission);
            }
            return row;
        });
    }
    async savePermissions(user, items) {
        if (user.role !== "HEADQUARTERS")
            throw new common_1.ForbiddenException("只有总部可以修改角色权限");
        const validRoles = new Set(Object.keys(SystemService_1.DEFAULT_PERMISSIONS));
        const validPermissions = new Set(SystemService_1.ALL_PERMISSIONS);
        for (const item of items) {
            if (!validRoles.has(item.role) || !validPermissions.has(item.permission))
                throw new common_1.BadRequestException("权限项不合法");
            if (item.role === "HEADQUARTERS" && !item.allowed)
                throw new common_1.BadRequestException("不能关闭总部权限");
        }
        await this.prisma.$transaction([
            this.prisma.permissionOverride.deleteMany({}),
            this.prisma.permissionOverride.createMany({
                data: items
                    .filter((item) => item.allowed !== (SystemService_1.DEFAULT_PERMISSIONS[item.role] || []).includes(item.permission))
                    .map((item) => ({ role: item.role, permission: item.permission, allowed: item.allowed })),
            }),
        ]);
        await this.prisma.auditLog.create({ data: { userId: user.id, action: "SAVE_PERMISSIONS", entityType: "PermissionOverride", entityId: "-" } });
        return { success: true };
    }
    async effectivePermissions() {
        const overrides = await this.prisma.permissionOverride.findMany();
        const overrideMap = new Map(overrides.map((item) => [`${item.role}:${item.permission}`, item.allowed]));
        const matrix = {};
        for (const role of Object.keys(SystemService_1.DEFAULT_PERMISSIONS)) {
            matrix[role] = SystemService_1.ALL_PERMISSIONS.filter((permission) => {
                const key = `${role}:${permission}`;
                return overrideMap.has(key) ? overrideMap.get(key) : (SystemService_1.DEFAULT_PERMISSIONS[role] || []).includes(permission);
            });
        }
        return matrix;
    }
    async status(user) {
        if (!["HEADQUARTERS", "FINANCE", "MANAGER"].includes(user.role))
            throw new common_1.ForbiddenException("无权查看系统状态");
        if (!user_session_1.GLOBAL_ROLES.has(user.role) && !user.storeId)
            throw new common_1.ForbiddenException("账号未绑定门店");
        const startedAt = new Date(Date.now() - process.uptime() * 1000);
        const storeId = user_session_1.GLOBAL_ROLES.has(user.role) ? undefined : user.storeId;
        const [storeCount, userCount, sessionCount, auditCount] = await Promise.all([
            storeId ? Promise.resolve(1) : this.prisma.store.count(),
            this.prisma.user.count({ where: storeId ? { storeId } : {} }),
            this.prisma.gameSession.count({ where: storeId ? { storeId } : {} }),
            this.prisma.auditLog.count({ where: storeId ? { user: { storeId } } : {} }),
        ]);
        await this.prisma.$queryRaw `SELECT 1`;
        return {
            status: "ok", database: "connected", environment: process.env.NODE_ENV ?? "development",
            startedAt: startedAt.toISOString(), uptimeSeconds: Math.round(process.uptime()),
            counts: { stores: storeCount, users: userCount, sessions: sessionCount, auditLogs: auditCount },
        };
    }
    auditLogs(user, action) {
        const userWhere = user_session_1.GLOBAL_ROLES.has(user.role) ? {} : { user: { storeId: user.storeId ?? "__none__" } };
        return this.prisma.auditLog.findMany({
            where: { ...userWhere, ...(action ? { action } : {}) },
            include: { user: { select: { id: true, name: true, role: true, storeId: true, store: true } } },
            orderBy: { createdAt: "desc" }, take: 300,
        });
    }
    transfers(user) {
        if (user.role !== "HEADQUARTERS")
            throw new common_1.ForbiddenException("只有总部可以查看调店记录");
        return this.prisma.employeeTransfer.findMany({
            include: {
                user: { select: { id: true, name: true, username: true } }, fromStore: true, toStore: true,
                operator: { select: { id: true, name: true } },
            },
            orderBy: { createdAt: "desc" }, take: 200,
        });
    }
    async transferUser(operator, userId, storeId, reason) {
        if (operator.role !== "HEADQUARTERS")
            throw new common_1.ForbiddenException("只有总部可以执行员工调店");
        const [employee, store] = await Promise.all([
            this.prisma.user.findUnique({ where: { id: userId } }), this.prisma.store.findFirst({ where: { id: storeId, active: true } }),
        ]);
        if (!employee)
            throw new common_1.NotFoundException("员工不存在");
        if (!store)
            throw new common_1.BadRequestException("目标门店不存在或已停用");
        if (user_session_1.GLOBAL_ROLES.has(employee.role))
            throw new common_1.BadRequestException("总部和财务账号不能调入门店");
        if (employee.storeId === storeId)
            throw new common_1.BadRequestException("员工已在该门店");
        const result = await this.prisma.$transaction(async (tx) => {
            const updated = await tx.user.update({ where: { id: userId }, data: { storeId }, select: { id: true, name: true, username: true, role: true, storeId: true, store: true } });
            const transfer = await tx.employeeTransfer.create({
                data: { userId, fromStoreId: employee.storeId, toStoreId: storeId, operatorId: operator.id, reason },
                include: { fromStore: true, toStore: true },
            });
            await tx.auditLog.create({ data: { userId: operator.id, action: "TRANSFER_USER", entityType: "User", entityId: userId, payload: JSON.stringify({ fromStoreId: employee.storeId, toStoreId: storeId, reason }) } });
            return { user: updated, transfer };
        });
        return result;
    }
    async resetPassword(operator, userId, newPassword) {
        const employee = await this.prisma.user.findUnique({ where: { id: userId } });
        if (!employee)
            throw new common_1.NotFoundException("员工不存在");
        const allowed = operator.role === "HEADQUARTERS" || (operator.role === "MANAGER" && operator.storeId && operator.storeId === employee.storeId);
        if (!allowed)
            throw new common_1.ForbiddenException("无权重置该员工密码");
        if (employee.role === "HEADQUARTERS" && operator.id !== employee.id)
            throw new common_1.ForbiddenException("不能重置其他总部账号密码");
        await this.prisma.user.update({
            where: { id: userId },
            data: { passwordHash: await (0, bcryptjs_1.hash)(newPassword, 10), mustChangePassword: true },
        });
        await this.prisma.auditLog.create({ data: { userId: operator.id, action: "RESET_USER_PASSWORD", entityType: "User", entityId: userId } });
        return { success: true };
    }
};
exports.SystemService = SystemService;
exports.SystemService = SystemService = SystemService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], SystemService);
//# sourceMappingURL=system.service.js.map