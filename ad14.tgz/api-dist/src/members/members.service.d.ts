import { type UserSession } from "../common/user-session";
import { PrismaService } from "../prisma/prisma.service";
export declare class MembersService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private scope;
    list(user: UserSession, storeId?: string, search?: string): Promise<{
        phone: string;
        ledgers: never[];
        id: string;
        name: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        tier: string;
        openedById: string | null;
        storeId: string;
        store: {
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            active: boolean;
        };
    }[]> | import("@prisma/client").Prisma.PrismaPromise<({
        openedBy: {
            id: string;
            name: string;
        } | null;
        store: {
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            active: boolean;
        };
        ledgers: ({
            operator: {
                id: string;
                name: string;
            } | null;
        } & {
            id: string;
            createdAt: Date;
            type: string;
            amountCents: number;
            balanceAfterCents: number;
            note: string | null;
            memberId: string;
            operatorId: string | null;
        })[];
    } & {
        id: string;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
    })[]>;
    create(user: UserSession, data: {
        storeId: string;
        name: string;
        phone: string;
        initialAmountCents: number;
        paymentProofUrl?: string;
        source?: string;
    }): Promise<{
        store: {
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            active: boolean;
        };
        ledgers: {
            id: string;
            createdAt: Date;
            type: string;
            amountCents: number;
            balanceAfterCents: number;
            note: string | null;
            memberId: string;
            operatorId: string | null;
        }[];
    } & {
        id: string;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
    }>;
    approve(user: UserSession, id: string): Promise<{
        store: {
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            active: boolean;
        };
        ledgers: {
            id: string;
            createdAt: Date;
            type: string;
            amountCents: number;
            balanceAfterCents: number;
            note: string | null;
            memberId: string;
            operatorId: string | null;
        }[];
    } & {
        id: string;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
    }>;
    consume(user: UserSession, id: string, amountCents: number, note?: string): Promise<{
        store: {
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            active: boolean;
        };
        ledgers: {
            id: string;
            createdAt: Date;
            type: string;
            amountCents: number;
            balanceAfterCents: number;
            note: string | null;
            memberId: string;
            operatorId: string | null;
        }[];
    } & {
        id: string;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
    }>;
    adjust(user: UserSession, id: string, type: string, amountCents: number, note: string): Promise<{
        store: {
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            active: boolean;
        };
        ledgers: ({
            operator: {
                id: string;
                name: string;
            } | null;
        } & {
            id: string;
            createdAt: Date;
            type: string;
            amountCents: number;
            balanceAfterCents: number;
            note: string | null;
            memberId: string;
            operatorId: string | null;
        })[];
    } & {
        id: string;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
    }>;
    updateTier(user: UserSession, id: string, tier: string): Promise<{
        openedBy: {
            id: string;
            name: string;
        } | null;
        store: {
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            active: boolean;
        };
        ledgers: {
            id: string;
            createdAt: Date;
            type: string;
            amountCents: number;
            balanceAfterCents: number;
            note: string | null;
            memberId: string;
            operatorId: string | null;
        }[];
    } & {
        id: string;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
    }>;
    rankings(user: UserSession, query: {
        storeId?: string;
        from?: string;
        to?: string;
    }): Promise<{
        rechargeRanking: {
            userId: string;
            name: string;
            amountCents: number;
            count: number;
        }[];
        openerRanking: {
            userId: string;
            name: string;
            count: number;
        }[];
    }>;
}
