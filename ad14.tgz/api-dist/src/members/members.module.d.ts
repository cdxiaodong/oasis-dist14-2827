export declare class MembersModule {
}
