import type { UserSession } from "../common/user-session";
import { CatalogService } from "./catalog.service";
declare class StoreDto {
    code: string;
    name: string;
    city: string;
    address?: string;
}
declare class UpdateStoreDto {
    code?: string;
    name?: string;
    city?: string;
    address?: string;
    active?: boolean;
}
declare class RoomDto {
    storeId: string;
    name: string;
    capacity: number;
}
declare class UpdateRoomDto {
    name?: string;
    capacity?: number;
    active?: boolean;
}
declare class UserDto {
    username: string;
    password: string;
    name: string;
    role: string;
    phone?: string | null;
    storeId?: string;
}
declare class UpdateUserDto {
    name?: string;
    phone?: string | null;
    role?: string;
    active?: boolean;
}
declare class CreateScriptDto {
    name: string;
    storeId: string;
    version?: number;
    category?: string;
    theme?: string;
    playerCount: number;
    minPlayerCount?: number;
    priceCents: number;
    durationMinutes: number;
    sessionFactor?: number;
    needsAssistant?: boolean;
    needsNpc?: boolean;
    assistantCount?: number;
    npcCount?: number;
    assistantFeeTiers?: Array<{
        name: string;
        amountCents: number;
    }>;
    npcFeeTiers?: Array<{
        name: string;
        amountCents: number;
    }>;
    requiredPreparationLabels?: string[];
    requiredMaterialLabels?: string[];
    preparationExamples?: Record<string, string>;
    materialExamples?: Record<string, string>;
}
declare class UpdateScriptDto {
    name?: string;
    category?: string;
    theme?: string;
    playerCount?: number;
    minPlayerCount?: number;
    priceCents?: number;
    durationMinutes?: number;
    sessionFactor?: number;
    needsAssistant?: boolean;
    needsNpc?: boolean;
    assistantCount?: number;
    npcCount?: number;
    assistantFeeTiers?: Array<{
        name: string;
        amountCents: number;
    }>;
    npcFeeTiers?: Array<{
        name: string;
        amountCents: number;
    }>;
    requiredPreparationLabels?: string[];
    requiredMaterialLabels?: string[];
    preparationExamples?: Record<string, string>;
    materialExamples?: Record<string, string>;
    active?: boolean;
}
declare class VipCardRuleDto {
    storeId: string;
    cardType: string;
    rechargeCents: number;
    receiveCents: number;
    boxDiscount?: number;
    cityDiscount?: number;
    unifiedDiscount?: number;
    maxUsers?: number;
    cardTitle?: string;
}
declare class UpdateVipCardRuleDto {
    rechargeCents?: number;
    receiveCents?: number;
    boxDiscount?: number;
    cityDiscount?: number;
    unifiedDiscount?: number;
    maxUsers?: number;
    cardTitle?: string;
    active?: boolean;
}
declare class ActivityTypeDto {
    name: string;
    storeId?: string;
    defaultDiscountCents?: number;
    sortOrder?: number;
}
declare class UpdateActivityTypeDto {
    name?: string;
    defaultDiscountCents?: number;
    active?: boolean;
    sortOrder?: number;
}
export declare class CatalogController {
    private readonly catalog;
    constructor(catalog: CatalogService);
    stores(user: UserSession): import("@prisma/client").Prisma.PrismaPromise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        code: string;
        city: string;
        address: string | null;
        latitude: number | null;
        longitude: number | null;
        attendanceRadiusMeters: number;
        attendanceMaxAccuracyMeters: number;
        attendanceLocationUpdatedAt: Date | null;
    }[]>;
    createStore(user: UserSession, dto: StoreDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        code: string;
        city: string;
        address: string | null;
        latitude: number | null;
        longitude: number | null;
        attendanceRadiusMeters: number;
        attendanceMaxAccuracyMeters: number;
        attendanceLocationUpdatedAt: Date | null;
    }>;
    updateStore(user: UserSession, id: string, dto: UpdateStoreDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        code: string;
        city: string;
        address: string | null;
        latitude: number | null;
        longitude: number | null;
        attendanceRadiusMeters: number;
        attendanceMaxAccuracyMeters: number;
        attendanceLocationUpdatedAt: Date | null;
    }>;
    rooms(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        capacity: number;
    })[]>;
    createRoom(user: UserSession, dto: RoomDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        capacity: number;
    }>;
    updateRoom(user: UserSession, id: string, dto: UpdateRoomDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        capacity: number;
    }>;
    users(user: UserSession, storeId?: string): never[] | import("@prisma/client").Prisma.PrismaPromise<{
        id: string;
        storeId: string | null;
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
        name: string;
        role: string;
        active: boolean;
    }[]> | Promise<{
        wechatBound: boolean;
        id: string;
        storeId: string | null;
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
        username: string;
        name: string;
        role: string;
        phone: string | null;
        lastWechatLoginAt: Date | null;
        active: boolean;
    }[]>;
    createUser(user: UserSession, dto: UserDto): Promise<{
        id: string;
        storeId: string | null;
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
        username: string;
        name: string;
        role: string;
        phone: string | null;
        lastWechatLoginAt: Date | null;
        active: boolean;
    }>;
    updateUser(user: UserSession, id: string, dto: UpdateUserDto): Promise<{
        id: string;
        storeId: string | null;
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
        username: string;
        name: string;
        role: string;
        phone: string | null;
        lastWechatLoginAt: Date | null;
        active: boolean;
    }>;
    unbindWechat(user: UserSession, id: string): Promise<{
        success: boolean;
    }>;
    scripts(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        version: number;
        category: string;
        theme: string;
        playerCount: number;
        minPlayerCount: number;
        priceCents: number;
        memberPriceCents: number;
        durationMinutes: number;
        sessionFactor: number;
        needsAssistant: boolean;
        needsNpc: boolean;
        assistantCount: number;
        npcCount: number;
        assistantFeeTiers: string;
        npcFeeTiers: string;
        eligibleHostIds: string;
        eligibleAssistantIds: string;
        eligibleNpcIds: string;
        requiredPreparationLabels: string;
        requiredMaterialLabels: string;
        preparationExamples: string;
        materialExamples: string;
    })[]>;
    createScript(user: UserSession, dto: CreateScriptDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        version: number;
        category: string;
        theme: string;
        playerCount: number;
        minPlayerCount: number;
        priceCents: number;
        memberPriceCents: number;
        durationMinutes: number;
        sessionFactor: number;
        needsAssistant: boolean;
        needsNpc: boolean;
        assistantCount: number;
        npcCount: number;
        assistantFeeTiers: string;
        npcFeeTiers: string;
        eligibleHostIds: string;
        eligibleAssistantIds: string;
        eligibleNpcIds: string;
        requiredPreparationLabels: string;
        requiredMaterialLabels: string;
        preparationExamples: string;
        materialExamples: string;
    }>;
    updateScript(user: UserSession, id: string, dto: UpdateScriptDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        version: number;
        category: string;
        theme: string;
        playerCount: number;
        minPlayerCount: number;
        priceCents: number;
        memberPriceCents: number;
        durationMinutes: number;
        sessionFactor: number;
        needsAssistant: boolean;
        needsNpc: boolean;
        assistantCount: number;
        npcCount: number;
        assistantFeeTiers: string;
        npcFeeTiers: string;
        eligibleHostIds: string;
        eligibleAssistantIds: string;
        eligibleNpcIds: string;
        requiredPreparationLabels: string;
        requiredMaterialLabels: string;
        preparationExamples: string;
        materialExamples: string;
    }>;
    vipRules(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            name: string;
            city: string;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        active: boolean;
        cardType: string;
        rechargeCents: number;
        receiveCents: number;
        boxDiscount: number | null;
        cityDiscount: number | null;
        unifiedDiscount: number | null;
        maxUsers: number | null;
        cardTitle: string;
    })[]>;
    createVipRule(user: UserSession, dto: VipCardRuleDto): Promise<{
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        active: boolean;
        cardType: string;
        rechargeCents: number;
        receiveCents: number;
        boxDiscount: number | null;
        cityDiscount: number | null;
        unifiedDiscount: number | null;
        maxUsers: number | null;
        cardTitle: string;
    }>;
    updateVipRule(user: UserSession, id: string, dto: UpdateVipCardRuleDto): Promise<{
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        active: boolean;
        cardType: string;
        rechargeCents: number;
        receiveCents: number;
        boxDiscount: number | null;
        cityDiscount: number | null;
        unifiedDiscount: number | null;
        maxUsers: number | null;
        cardTitle: string;
    }>;
    activityTypes(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        storeId: string | null;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        defaultDiscountCents: number;
        sortOrder: number;
    })[]>;
    createActivityType(user: UserSession, dto: ActivityTypeDto): Promise<{
        id: string;
        storeId: string | null;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        defaultDiscountCents: number;
        sortOrder: number;
    }>;
    updateActivityType(user: UserSession, id: string, dto: UpdateActivityTypeDto): Promise<{
        id: string;
        storeId: string | null;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        defaultDiscountCents: number;
        sortOrder: number;
    }>;
    deleteActivityType(user: UserSession, id: string): Promise<{
        success: boolean;
    }>;
    private serializeScript;
}
export {};
