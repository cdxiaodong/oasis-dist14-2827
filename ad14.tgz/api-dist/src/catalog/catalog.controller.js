"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CatalogController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/current-user.decorator");
const catalog_service_1 = require("./catalog.service");
const business_rules_1 = require("../common/business-rules");
class StoreDto {
    code;
    name;
    city;
    address;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StoreDto.prototype, "code", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StoreDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StoreDto.prototype, "city", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StoreDto.prototype, "address", void 0);
class UpdateStoreDto {
    code;
    name;
    city;
    address;
    active;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateStoreDto.prototype, "code", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateStoreDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateStoreDto.prototype, "city", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateStoreDto.prototype, "address", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateStoreDto.prototype, "active", void 0);
class RoomDto {
    storeId;
    name;
    capacity;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RoomDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RoomDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], RoomDto.prototype, "capacity", void 0);
class UpdateRoomDto {
    name;
    capacity;
    active;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateRoomDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], UpdateRoomDto.prototype, "capacity", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateRoomDto.prototype, "active", void 0);
class UserDto {
    username;
    password;
    name;
    role;
    phone;
    storeId;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UserDto.prototype, "username", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(6),
    __metadata("design:type", String)
], UserDto.prototype, "password", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UserDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsIn)(["HEADQUARTERS", "FINANCE", "MANAGER", "DM", "ASSISTANT", "NPC", "STAFF", "CUSTOMER_SERVICE"]),
    __metadata("design:type", String)
], UserDto.prototype, "role", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^1\d{10}$/, { message: "手机号格式不正确" }),
    __metadata("design:type", Object)
], UserDto.prototype, "phone", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UserDto.prototype, "storeId", void 0);
class UpdateUserDto {
    name;
    phone;
    role;
    active;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateUserDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^1\d{10}$/, { message: "手机号格式不正确" }),
    __metadata("design:type", Object)
], UpdateUserDto.prototype, "phone", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["HEADQUARTERS", "FINANCE", "MANAGER", "DM", "ASSISTANT", "NPC", "STAFF", "CUSTOMER_SERVICE"]),
    __metadata("design:type", String)
], UpdateUserDto.prototype, "role", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateUserDto.prototype, "active", void 0);
class CreateScriptDto {
    name;
    storeId;
    version;
    category;
    theme;
    playerCount;
    minPlayerCount;
    priceCents;
    durationMinutes;
    sessionFactor;
    needsAssistant;
    needsNpc;
    assistantCount;
    npcCount;
    assistantFeeTiers;
    npcFeeTiers;
    requiredPreparationLabels;
    requiredMaterialLabels;
    preparationExamples;
    materialExamples;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateScriptDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateScriptDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateScriptDto.prototype, "version", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["BOX", "CITY_LIMIT"]),
    __metadata("design:type", String)
], CreateScriptDto.prototype, "category", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["HORROR", "EMOTION", "REASONING", "JOY_MECHANISM"]),
    __metadata("design:type", String)
], CreateScriptDto.prototype, "theme", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateScriptDto.prototype, "playerCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateScriptDto.prototype, "minPlayerCount", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateScriptDto.prototype, "priceCents", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(30),
    __metadata("design:type", Number)
], CreateScriptDto.prototype, "durationMinutes", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CreateScriptDto.prototype, "sessionFactor", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateScriptDto.prototype, "needsAssistant", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateScriptDto.prototype, "needsNpc", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateScriptDto.prototype, "assistantCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateScriptDto.prototype, "npcCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], CreateScriptDto.prototype, "assistantFeeTiers", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], CreateScriptDto.prototype, "npcFeeTiers", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], CreateScriptDto.prototype, "requiredPreparationLabels", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], CreateScriptDto.prototype, "requiredMaterialLabels", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], CreateScriptDto.prototype, "preparationExamples", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], CreateScriptDto.prototype, "materialExamples", void 0);
class UpdateScriptDto {
    name;
    category;
    theme;
    playerCount;
    minPlayerCount;
    priceCents;
    durationMinutes;
    sessionFactor;
    needsAssistant;
    needsNpc;
    assistantCount;
    npcCount;
    assistantFeeTiers;
    npcFeeTiers;
    requiredPreparationLabels;
    requiredMaterialLabels;
    preparationExamples;
    materialExamples;
    active;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateScriptDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["BOX", "CITY_LIMIT"]),
    __metadata("design:type", String)
], UpdateScriptDto.prototype, "category", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["HORROR", "EMOTION", "REASONING", "JOY_MECHANISM"]),
    __metadata("design:type", String)
], UpdateScriptDto.prototype, "theme", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], UpdateScriptDto.prototype, "playerCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], UpdateScriptDto.prototype, "minPlayerCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateScriptDto.prototype, "priceCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(30),
    __metadata("design:type", Number)
], UpdateScriptDto.prototype, "durationMinutes", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateScriptDto.prototype, "sessionFactor", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateScriptDto.prototype, "needsAssistant", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateScriptDto.prototype, "needsNpc", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateScriptDto.prototype, "assistantCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateScriptDto.prototype, "npcCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], UpdateScriptDto.prototype, "assistantFeeTiers", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], UpdateScriptDto.prototype, "npcFeeTiers", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], UpdateScriptDto.prototype, "requiredPreparationLabels", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], UpdateScriptDto.prototype, "requiredMaterialLabels", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], UpdateScriptDto.prototype, "preparationExamples", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], UpdateScriptDto.prototype, "materialExamples", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateScriptDto.prototype, "active", void 0);
class VipCardRuleDto {
    storeId;
    cardType;
    rechargeCents;
    receiveCents;
    boxDiscount;
    cityDiscount;
    unifiedDiscount;
    maxUsers;
    cardTitle;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], VipCardRuleDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsIn)(["SINGLE", "DOUBLE", "MULTI"]),
    __metadata("design:type", String)
], VipCardRuleDto.prototype, "cardType", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], VipCardRuleDto.prototype, "rechargeCents", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], VipCardRuleDto.prototype, "receiveCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], VipCardRuleDto.prototype, "boxDiscount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], VipCardRuleDto.prototype, "cityDiscount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], VipCardRuleDto.prototype, "unifiedDiscount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], VipCardRuleDto.prototype, "maxUsers", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], VipCardRuleDto.prototype, "cardTitle", void 0);
class UpdateVipCardRuleDto {
    rechargeCents;
    receiveCents;
    boxDiscount;
    cityDiscount;
    unifiedDiscount;
    maxUsers;
    cardTitle;
    active;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateVipCardRuleDto.prototype, "rechargeCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateVipCardRuleDto.prototype, "receiveCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateVipCardRuleDto.prototype, "boxDiscount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateVipCardRuleDto.prototype, "cityDiscount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateVipCardRuleDto.prototype, "unifiedDiscount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], UpdateVipCardRuleDto.prototype, "maxUsers", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateVipCardRuleDto.prototype, "cardTitle", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateVipCardRuleDto.prototype, "active", void 0);
class ActivityTypeDto {
    name;
    storeId;
    defaultDiscountCents;
    sortOrder;
}
__decorate([
    (0, class_validator_1.IsIn)(business_rules_1.ACTIVITY_TYPE_NAMES),
    __metadata("design:type", String)
], ActivityTypeDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ActivityTypeDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], ActivityTypeDto.prototype, "defaultDiscountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    __metadata("design:type", Number)
], ActivityTypeDto.prototype, "sortOrder", void 0);
class UpdateActivityTypeDto {
    name;
    defaultDiscountCents;
    active;
    sortOrder;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(business_rules_1.ACTIVITY_TYPE_NAMES),
    __metadata("design:type", String)
], UpdateActivityTypeDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateActivityTypeDto.prototype, "defaultDiscountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateActivityTypeDto.prototype, "active", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    __metadata("design:type", Number)
], UpdateActivityTypeDto.prototype, "sortOrder", void 0);
let CatalogController = class CatalogController {
    catalog;
    constructor(catalog) {
        this.catalog = catalog;
    }
    stores(user) { return this.catalog.stores(user); }
    createStore(user, dto) { return this.catalog.createStore(user, dto); }
    updateStore(user, id, dto) { return this.catalog.updateStore(user, id, dto); }
    rooms(user, storeId) { return this.catalog.rooms(user, storeId); }
    createRoom(user, dto) { return this.catalog.createRoom(user, dto); }
    updateRoom(user, id, dto) { return this.catalog.updateRoom(user, id, dto); }
    users(user, storeId) { return this.catalog.users(user, storeId); }
    createUser(user, dto) { return this.catalog.createUser(user, dto); }
    updateUser(user, id, dto) { return this.catalog.updateUser(user, id, dto); }
    unbindWechat(user, id) { return this.catalog.unbindWechat(user, id); }
    scripts(user, storeId) { return this.catalog.scripts(user, storeId); }
    createScript(user, dto) {
        return this.catalog.createScript(user, this.serializeScript(dto));
    }
    updateScript(user, id, dto) {
        return this.catalog.updateScript(user, id, this.serializeScript(dto));
    }
    vipRules(user, storeId) { return this.catalog.vipRules(user, storeId); }
    createVipRule(user, dto) { return this.catalog.createVipRule(user, dto); }
    updateVipRule(user, id, dto) { return this.catalog.updateVipRule(user, id, dto); }
    activityTypes(user, storeId) { return this.catalog.activityTypes(user, storeId); }
    createActivityType(user, dto) { return this.catalog.createActivityType(user, dto); }
    updateActivityType(user, id, dto) { return this.catalog.updateActivityType(user, id, dto); }
    deleteActivityType(user, id) { return this.catalog.deleteActivityType(user, id); }
    serializeScript(dto) {
        const jsonFields = ["assistantFeeTiers", "npcFeeTiers", "requiredPreparationLabels", "requiredMaterialLabels", "preparationExamples", "materialExamples"];
        const result = { ...dto };
        for (const field of jsonFields) {
            if (dto[field] !== undefined)
                result[field] = JSON.stringify(dto[field]);
        }
        return result;
    }
};
exports.CatalogController = CatalogController;
__decorate([
    (0, common_1.Get)("stores"),
    (0, swagger_1.ApiOperation)({ summary: "门店列表" }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "stores", null);
__decorate([
    (0, common_1.Post)("stores"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, StoreDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "createStore", null);
__decorate([
    (0, common_1.Patch)("stores/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateStoreDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "updateStore", null);
__decorate([
    (0, common_1.Get)("rooms"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "rooms", null);
__decorate([
    (0, common_1.Post)("rooms"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, RoomDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "createRoom", null);
__decorate([
    (0, common_1.Patch)("rooms/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateRoomDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "updateRoom", null);
__decorate([
    (0, common_1.Get)("users"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "users", null);
__decorate([
    (0, common_1.Post)("users"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, UserDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "createUser", null);
__decorate([
    (0, common_1.Patch)("users/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateUserDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "updateUser", null);
__decorate([
    (0, common_1.Post)("users/:id/unbind-wechat"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "unbindWechat", null);
__decorate([
    (0, common_1.Get)("scripts"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "scripts", null);
__decorate([
    (0, common_1.Post)("scripts"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, CreateScriptDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "createScript", null);
__decorate([
    (0, common_1.Patch)("scripts/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateScriptDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "updateScript", null);
__decorate([
    (0, common_1.Get)("vip-rules"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "vipRules", null);
__decorate([
    (0, common_1.Post)("vip-rules"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, VipCardRuleDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "createVipRule", null);
__decorate([
    (0, common_1.Patch)("vip-rules/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateVipCardRuleDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "updateVipRule", null);
__decorate([
    (0, common_1.Get)("activity-types"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "activityTypes", null);
__decorate([
    (0, common_1.Post)("activity-types"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, ActivityTypeDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "createActivityType", null);
__decorate([
    (0, common_1.Patch)("activity-types/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateActivityTypeDto]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "updateActivityType", null);
__decorate([
    (0, common_1.Delete)("activity-types/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CatalogController.prototype, "deleteActivityType", null);
exports.CatalogController = CatalogController = __decorate([
    (0, swagger_1.ApiTags)("基础资料"),
    (0, common_1.Controller)("catalog"),
    __metadata("design:paramtypes", [catalog_service_1.CatalogService])
], CatalogController);
//# sourceMappingURL=catalog.controller.js.map