"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const core_1 = require("@nestjs/core");
const swagger_1 = require("@nestjs/swagger");
const app_module_1 = require("./app.module");
const global_exception_filter_1 = require("./common/global-exception.filter");
function validateJwtSecret(secret) {
    const WEAK = ["oasis-local-demo-secret", "secret", "changeme", "your-secret-key"];
    if (!secret || secret.length < 16) {
        throw new Error(`JWT_SECRET 长度不足 16 位，拒绝启动。请在 .env 中设置一个安全的随机密钥。`);
    }
    if (WEAK.includes(secret)) {
        throw new Error(`JWT_SECRET 使用了已知弱密钥，拒绝启动。请生成一个随机密钥。`);
    }
}
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    const config = app.get(config_1.ConfigService);
    const jwtSecret = config.get("JWT_SECRET", "");
    validateJwtSecret(jwtSecret);
    const isProd = config.get("NODE_ENV", "development") === "production";
    app.useBodyParser("json", { limit: "7mb" });
    app.setGlobalPrefix("api");
    app.enableCors({
        origin: config.get("ADMIN_ORIGIN", "http://localhost:5173").split(","),
        credentials: true,
    });
    app.useGlobalPipes(new common_1.ValidationPipe({ whitelist: true, transform: true, forbidNonWhitelisted: true }));
    app.useGlobalFilters(new global_exception_filter_1.GlobalExceptionFilter());
    if (!isProd) {
        const swaggerConfig = new swagger_1.DocumentBuilder()
            .setTitle("绿洲剧本杀多门店系统")
            .setDescription("门店、车次、会员、考勤、报销与经营统计 API")
            .setVersion("1.0.0")
            .addBearerAuth()
            .build();
        swagger_1.SwaggerModule.setup("api/docs", app, swagger_1.SwaggerModule.createDocument(app, swaggerConfig));
    }
    const port = config.get("PORT", 3000);
    const host = config.get("HOST", "127.0.0.1");
    await app.listen(port, host);
    if (!isProd) {
        console.log(`API running on http://${host}:${port}  Swagger: http://${host}:${port}/api/docs`);
    }
}
void bootstrap();
//# sourceMappingURL=main.js.map