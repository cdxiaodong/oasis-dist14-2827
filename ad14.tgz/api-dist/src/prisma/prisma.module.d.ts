export declare class PrismaModule {
}
