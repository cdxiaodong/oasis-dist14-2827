import { type UserSession } from "../common/user-session";
import { PrismaService } from "../prisma/prisma.service";
interface RangeQuery {
    storeId?: string;
    from: string;
    to: string;
}
export declare class WorkforceService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private scope;
    private requireManager;
    private requireScheduleAccess;
    private range;
    private includeShift;
    shifts(user: UserSession, query: RangeQuery): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        startAt: Date;
        status: string;
        userId: string;
        shiftType: string;
        endAt: Date;
    })[]>;
    createShift(user: UserSession, data: {
        storeId: string;
        userId: string;
        startAt: string;
        endAt: string;
        shiftType?: string;
        note?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        startAt: Date;
        status: string;
        userId: string;
        shiftType: string;
        endAt: Date;
    }>;
    updateShift(user: UserSession, id: string, data: {
        startAt?: string;
        endAt?: string;
        shiftType?: string;
        status?: string;
        note?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        startAt: Date;
        status: string;
        userId: string;
        shiftType: string;
        endAt: Date;
    }>;
    requests(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        shift: {
            id: string;
            note: string | null;
            storeId: string;
            createdById: string;
            createdAt: Date;
            updatedAt: Date;
            startAt: Date;
            status: string;
            userId: string;
            shiftType: string;
            endAt: Date;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
        requester: {
            id: string;
            name: string;
            role: string;
        };
        targetUser: {
            id: string;
            name: string;
            role: string;
        } | null;
    } & {
        id: string;
        type: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        reviewedById: string | null;
        respondedAt: Date | null;
        reason: string;
        reviewerComment: string | null;
        shiftId: string;
        requesterId: string;
        targetUserId: string | null;
    })[]>;
    createRequest(user: UserSession, data: {
        shiftId: string;
        type: string;
        reason: string;
        targetUserId?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        shift: {
            id: string;
            note: string | null;
            storeId: string;
            createdById: string;
            createdAt: Date;
            updatedAt: Date;
            startAt: Date;
            status: string;
            userId: string;
            shiftType: string;
            endAt: Date;
        };
        requester: {
            id: string;
            name: string;
        };
        targetUser: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        type: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        reviewedById: string | null;
        respondedAt: Date | null;
        reason: string;
        reviewerComment: string | null;
        shiftId: string;
        requesterId: string;
        targetUserId: string | null;
    }>;
    actionRequest(user: UserSession, id: string, action: string, comment?: string): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        shift: {
            id: string;
            note: string | null;
            storeId: string;
            createdById: string;
            createdAt: Date;
            updatedAt: Date;
            startAt: Date;
            status: string;
            userId: string;
            shiftType: string;
            endAt: Date;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
        requester: {
            id: string;
            name: string;
        };
        targetUser: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        type: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        reviewedById: string | null;
        respondedAt: Date | null;
        reason: string;
        reviewerComment: string | null;
        shiftId: string;
        requesterId: string;
        targetUserId: string | null;
    }>;
    availability(user: UserSession, query: RangeQuery): Promise<{
        range: {
            from: Date;
            to: Date;
        };
        rooms: {
            sessions: {
                id: any;
                code: any;
                scriptName: any;
                roomName: any;
                startAt: any;
                endAt: any;
            }[];
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        }[];
        users: {
            shifts: {
                id: string;
                note: string | null;
                storeId: string;
                createdById: string;
                createdAt: Date;
                updatedAt: Date;
                startAt: Date;
                status: string;
                userId: string;
                shiftType: string;
                endAt: Date;
            }[];
            sessions: {
                id: any;
                code: any;
                scriptName: any;
                roomName: any;
                startAt: any;
                endAt: any;
            }[];
            id: string;
            name: string;
            role: string;
        }[];
    }>;
    fees(user: UserSession, query: RangeQuery): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        } | null;
        session: {
            script: {
                id: string;
                storeId: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                version: number;
                category: string;
                theme: string;
                playerCount: number;
                minPlayerCount: number;
                priceCents: number;
                memberPriceCents: number;
                durationMinutes: number;
                sessionFactor: number;
                needsAssistant: boolean;
                needsNpc: boolean;
                assistantCount: number;
                npcCount: number;
                assistantFeeTiers: string;
                npcFeeTiers: string;
                eligibleHostIds: string;
                eligibleAssistantIds: string;
                eligibleNpcIds: string;
                requiredPreparationLabels: string;
                requiredMaterialLabels: string;
                preparationExamples: string;
                materialExamples: string;
            };
        } & {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            state: string;
            startAt: Date;
            expectedEndAt: Date;
            actualEndAt: Date | null;
            notes: string | null;
            rejectionNote: string | null;
            designationStatus: string;
            roomId: string;
            scriptId: string;
            hostId: string;
            assistantId: string | null;
            npcId: string | null;
            joinToken: string | null;
            joinEnabled: boolean;
        };
        confirmedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        sessionId: string;
        userId: string | null;
        feeType: string;
        confirmedById: string | null;
        confirmedAt: Date | null;
    })[]>;
    createFee(user: UserSession, data: {
        sessionId: string;
        feeType: string;
        amountCents: number;
        userId?: string;
        note?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        } | null;
        session: {
            script: {
                id: string;
                storeId: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                version: number;
                category: string;
                theme: string;
                playerCount: number;
                minPlayerCount: number;
                priceCents: number;
                memberPriceCents: number;
                durationMinutes: number;
                sessionFactor: number;
                needsAssistant: boolean;
                needsNpc: boolean;
                assistantCount: number;
                npcCount: number;
                assistantFeeTiers: string;
                npcFeeTiers: string;
                eligibleHostIds: string;
                eligibleAssistantIds: string;
                eligibleNpcIds: string;
                requiredPreparationLabels: string;
                requiredMaterialLabels: string;
                preparationExamples: string;
                materialExamples: string;
            };
        } & {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            state: string;
            startAt: Date;
            expectedEndAt: Date;
            actualEndAt: Date | null;
            notes: string | null;
            rejectionNote: string | null;
            designationStatus: string;
            roomId: string;
            scriptId: string;
            hostId: string;
            assistantId: string | null;
            npcId: string | null;
            joinToken: string | null;
            joinEnabled: boolean;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        sessionId: string;
        userId: string | null;
        feeType: string;
        confirmedById: string | null;
        confirmedAt: Date | null;
    }>;
    actionFee(user: UserSession, id: string, action: string, comment?: string): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        } | null;
        session: {
            script: {
                id: string;
                storeId: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                version: number;
                category: string;
                theme: string;
                playerCount: number;
                minPlayerCount: number;
                priceCents: number;
                memberPriceCents: number;
                durationMinutes: number;
                sessionFactor: number;
                needsAssistant: boolean;
                needsNpc: boolean;
                assistantCount: number;
                npcCount: number;
                assistantFeeTiers: string;
                npcFeeTiers: string;
                eligibleHostIds: string;
                eligibleAssistantIds: string;
                eligibleNpcIds: string;
                requiredPreparationLabels: string;
                requiredMaterialLabels: string;
                preparationExamples: string;
                materialExamples: string;
            };
        } & {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            state: string;
            startAt: Date;
            expectedEndAt: Date;
            actualEndAt: Date | null;
            notes: string | null;
            rejectionNote: string | null;
            designationStatus: string;
            roomId: string;
            scriptId: string;
            hostId: string;
            assistantId: string | null;
            npcId: string | null;
            joinToken: string | null;
            joinEnabled: boolean;
        };
        confirmedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        sessionId: string;
        userId: string | null;
        feeType: string;
        confirmedById: string | null;
        confirmedAt: Date | null;
    }>;
    feeSummary(user: UserSession, query: RangeQuery): Promise<{
        totalCents: number;
        pendingCents: number;
        byType: {
            type: string;
            amountCents: number;
        }[];
        byUser: {
            userId: string;
            name: string;
            amountCents: number;
        }[];
    }>;
    private assertPeriod;
    private assertShiftAvailable;
    private sessionSlot;
    private audit;
}
export {};
