"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkforceService = void 0;
const common_1 = require("@nestjs/common");
const user_session_1 = require("../common/user-session");
const prisma_service_1 = require("../prisma/prisma.service");
let WorkforceService = class WorkforceService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    scope(user, storeId) {
        if (user_session_1.GLOBAL_ROLES.has(user.role))
            return storeId;
        if (!user.storeId)
            throw new common_1.ForbiddenException("账号未绑定门店");
        if (storeId && storeId !== user.storeId)
            throw new common_1.ForbiddenException("无权访问其他门店");
        return user.storeId;
    }
    requireManager(user) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以维护排班");
    }
    requireScheduleAccess(user) {
        if (user.role === "CUSTOMER_SERVICE")
            throw new common_1.ForbiddenException("客服账号不开放排班与人员费用模块");
    }
    range(query) {
        const from = new Date(query.from), to = new Date(query.to);
        if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime()) || from >= to)
            throw new common_1.BadRequestException("时间范围不正确");
        if (to.getTime() - from.getTime() > 45 * 24 * 60 * 60 * 1000)
            throw new common_1.BadRequestException("单次最多查询 45 天");
        return { from, to };
    }
    includeShift = {
        store: true,
        user: { select: { id: true, name: true, role: true } },
        createdBy: { select: { id: true, name: true } },
    };
    shifts(user, query) {
        this.requireScheduleAccess(user);
        const storeId = this.scope(user, query.storeId);
        const { from, to } = this.range(query);
        return this.prisma.workShift.findMany({
            where: { ...(storeId ? { storeId } : {}), startAt: { lt: to }, endAt: { gt: from } },
            include: this.includeShift,
            orderBy: [{ startAt: "asc" }, { user: { name: "asc" } }],
        });
    }
    async createShift(user, data) {
        this.requireManager(user);
        const storeId = this.scope(user, data.storeId);
        if (!storeId)
            throw new common_1.BadRequestException("请选择门店");
        const startAt = new Date(data.startAt), endAt = new Date(data.endAt);
        this.assertPeriod(startAt, endAt);
        const employee = await this.prisma.user.findFirst({ where: { id: data.userId, storeId, active: true } });
        if (!employee)
            throw new common_1.BadRequestException("员工不属于所选门店或已停用");
        await this.assertShiftAvailable(data.userId, startAt, endAt);
        const shift = await this.prisma.workShift.create({
            data: { storeId, userId: data.userId, startAt, endAt, shiftType: data.shiftType ?? "WORK", note: data.note, createdById: user.id },
            include: this.includeShift,
        });
        await this.audit(user, "CREATE_WORK_SHIFT", "WorkShift", shift.id, { storeId, userId: data.userId, startAt, endAt });
        return shift;
    }
    async updateShift(user, id, data) {
        this.requireManager(user);
        const shift = await this.prisma.workShift.findUnique({ where: { id } });
        if (!shift)
            throw new common_1.NotFoundException("班次不存在");
        if (!(0, user_session_1.canAccessStore)(user, shift.storeId))
            throw new common_1.ForbiddenException("无权维护该班次");
        const startAt = data.startAt ? new Date(data.startAt) : shift.startAt;
        const endAt = data.endAt ? new Date(data.endAt) : shift.endAt;
        this.assertPeriod(startAt, endAt);
        if ((data.status ?? shift.status) === "SCHEDULED")
            await this.assertShiftAvailable(shift.userId, startAt, endAt, id);
        const updated = await this.prisma.workShift.update({
            where: { id }, data: { ...data, startAt: data.startAt ? startAt : undefined, endAt: data.endAt ? endAt : undefined }, include: this.includeShift,
        });
        await this.audit(user, "UPDATE_WORK_SHIFT", "WorkShift", id, data);
        return updated;
    }
    requests(user, storeId) {
        this.requireScheduleAccess(user);
        const scoped = this.scope(user, storeId);
        return this.prisma.scheduleRequest.findMany({
            where: scoped ? { storeId: scoped } : {},
            include: {
                store: true, shift: true,
                requester: { select: { id: true, name: true, role: true } },
                targetUser: { select: { id: true, name: true, role: true } },
                reviewedBy: { select: { id: true, name: true } },
            },
            orderBy: { createdAt: "desc" },
        });
    }
    async createRequest(user, data) {
        this.requireScheduleAccess(user);
        const shift = await this.prisma.workShift.findUnique({ where: { id: data.shiftId } });
        if (!shift)
            throw new common_1.NotFoundException("班次不存在");
        if (!(0, user_session_1.canAccessStore)(user, shift.storeId))
            throw new common_1.ForbiddenException("无权操作该班次");
        if (shift.userId !== user.id && !["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只能为自己的班次提交申请");
        if (shift.status !== "SCHEDULED")
            throw new common_1.BadRequestException("该班次已取消或已处理");
        const duplicate = await this.prisma.scheduleRequest.count({ where: { shiftId: shift.id, status: "PENDING" } });
        if (duplicate)
            throw new common_1.BadRequestException("该班次已有待处理申请");
        if (data.type === "SWAP") {
            if (!data.targetUserId)
                throw new common_1.BadRequestException("换班必须选择接班员工");
            if (data.targetUserId === shift.userId)
                throw new common_1.BadRequestException("不能与自己换班");
            const target = await this.prisma.user.findFirst({ where: { id: data.targetUserId, storeId: shift.storeId, active: true } });
            if (!target)
                throw new common_1.BadRequestException("接班员工不属于该门店或已停用");
            await this.assertShiftAvailable(target.id, shift.startAt, shift.endAt);
        }
        const request = await this.prisma.scheduleRequest.create({
            data: { ...data, storeId: shift.storeId, requesterId: shift.userId },
            include: { store: true, shift: true, requester: { select: { id: true, name: true } }, targetUser: { select: { id: true, name: true } } },
        });
        await this.audit(user, "CREATE_SCHEDULE_REQUEST", "ScheduleRequest", request.id, data);
        return request;
    }
    async actionRequest(user, id, action, comment) {
        this.requireManager(user);
        const request = await this.prisma.scheduleRequest.findUnique({ where: { id }, include: { shift: true } });
        if (!request)
            throw new common_1.NotFoundException("申请不存在");
        if (!(0, user_session_1.canAccessStore)(user, request.storeId))
            throw new common_1.ForbiddenException("无权处理该申请");
        if (request.status !== "PENDING")
            throw new common_1.BadRequestException("申请已经处理");
        if (action === "APPROVE" && request.type === "SWAP") {
            if (!request.targetUserId)
                throw new common_1.BadRequestException("申请缺少接班员工");
            await this.assertShiftAvailable(request.targetUserId, request.shift.startAt, request.shift.endAt);
        }
        const updated = await this.prisma.$transaction(async (tx) => {
            if (action === "APPROVE") {
                if (request.type === "LEAVE")
                    await tx.workShift.update({ where: { id: request.shiftId }, data: { status: "CANCELLED" } });
                else
                    await tx.workShift.update({ where: { id: request.shiftId }, data: { userId: request.targetUserId } });
            }
            return tx.scheduleRequest.update({
                where: { id }, data: { status: action === "APPROVE" ? "APPROVED" : "REJECTED", reviewerComment: comment, reviewedById: user.id, respondedAt: new Date() },
                include: { store: true, shift: true, requester: { select: { id: true, name: true } }, targetUser: { select: { id: true, name: true } }, reviewedBy: { select: { id: true, name: true } } },
            });
        });
        await this.audit(user, `SCHEDULE_REQUEST_${action}`, "ScheduleRequest", id, { comment });
        return updated;
    }
    async availability(user, query) {
        const storeId = this.scope(user, query.storeId);
        if (!storeId)
            throw new common_1.BadRequestException("请选择门店查看可用情况");
        const { from, to } = this.range(query);
        const [rooms, users, shifts, sessions] = await Promise.all([
            this.prisma.room.findMany({ where: { storeId, active: true }, orderBy: { name: "asc" } }),
            this.prisma.user.findMany({ where: { storeId, active: true, ...(user.role === "CUSTOMER_SERVICE" ? { role: "DM" } : {}) }, select: { id: true, name: true, role: true }, orderBy: { name: "asc" } }),
            this.prisma.workShift.findMany({ where: { storeId, status: "SCHEDULED", startAt: { lt: to }, endAt: { gt: from } } }),
            this.prisma.gameSession.findMany({
                where: { storeId, state: { not: "CANCELLED" }, startAt: { lt: to }, expectedEndAt: { gt: from } },
                include: { script: { select: { name: true } }, room: { select: { id: true, name: true } }, host: { select: { id: true, name: true } }, staffAssignments: { where: { status: { in: ["PENDING", "ACCEPTED"] } }, include: { user: { select: { id: true, name: true } } } } },
                orderBy: { startAt: "asc" },
            }),
        ]);
        return {
            range: { from, to },
            rooms: rooms.map((room) => ({ ...room, sessions: sessions.filter((session) => session.roomId === room.id).map(this.sessionSlot) })),
            users: users.map((employee) => ({
                ...employee,
                shifts: shifts.filter((shift) => shift.userId === employee.id),
                sessions: sessions.filter((session) => session.hostId === employee.id || session.staffAssignments.some((item) => item.userId === employee.id)).map(this.sessionSlot),
            })),
        };
    }
    fees(user, query) {
        this.requireScheduleAccess(user);
        const storeId = this.scope(user, query.storeId);
        const { from, to } = this.range(query);
        return this.prisma.sessionStaffFee.findMany({
            where: { ...(storeId ? { storeId } : {}), session: { startAt: { gte: from, lt: to } } },
            include: { store: true, session: { include: { script: true } }, user: { select: { id: true, name: true, role: true } }, createdBy: { select: { id: true, name: true } }, confirmedBy: { select: { id: true, name: true } } },
            orderBy: { createdAt: "desc" },
        });
    }
    async createFee(user, data) {
        this.requireManager(user);
        const session = await this.prisma.gameSession.findUnique({ where: { id: data.sessionId } });
        if (!session)
            throw new common_1.NotFoundException("车次不存在");
        if (!(0, user_session_1.canAccessStore)(user, session.storeId))
            throw new common_1.ForbiddenException("无权维护该车次费用");
        if (data.userId) {
            const employee = await this.prisma.user.findFirst({ where: { id: data.userId, storeId: session.storeId, active: true } });
            if (!employee)
                throw new common_1.BadRequestException("费用归属员工不属于该门店或已停用");
        }
        const fee = await this.prisma.sessionStaffFee.create({
            data: { ...data, storeId: session.storeId, createdById: user.id },
            include: { store: true, session: { include: { script: true } }, user: { select: { id: true, name: true, role: true } }, createdBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, "CREATE_SESSION_STAFF_FEE", "SessionStaffFee", fee.id, data);
        return fee;
    }
    async actionFee(user, id, action, comment) {
        if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长、财务或总部可以确认费用");
        const fee = await this.prisma.sessionStaffFee.findUnique({ where: { id } });
        if (!fee)
            throw new common_1.NotFoundException("费用记录不存在");
        if (!(0, user_session_1.canAccessStore)(user, fee.storeId))
            throw new common_1.ForbiddenException("无权处理该费用");
        if (fee.status !== "PENDING")
            throw new common_1.BadRequestException("费用已经处理");
        const updated = await this.prisma.sessionStaffFee.update({
            where: { id }, data: { status: action === "APPROVE" ? "CONFIRMED" : "REJECTED", confirmedById: user.id, confirmedAt: new Date(), note: comment ? `${fee.note ? `${fee.note}；` : ""}${comment}` : fee.note },
            include: { store: true, session: { include: { script: true } }, user: { select: { id: true, name: true, role: true } }, createdBy: { select: { id: true, name: true } }, confirmedBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, `SESSION_STAFF_FEE_${action}`, "SessionStaffFee", id, { comment });
        return updated;
    }
    async feeSummary(user, query) {
        const fees = await this.fees(user, query);
        const confirmed = fees.filter((item) => item.status === "CONFIRMED");
        const byType = new Map(), byUser = new Map();
        for (const fee of confirmed) {
            byType.set(fee.feeType, (byType.get(fee.feeType) ?? 0) + fee.amountCents);
            if (fee.user) {
                const item = byUser.get(fee.user.id) ?? { userId: fee.user.id, name: fee.user.name, amountCents: 0 };
                item.amountCents += fee.amountCents;
                byUser.set(fee.user.id, item);
            }
        }
        return { totalCents: confirmed.reduce((sum, item) => sum + item.amountCents, 0), pendingCents: fees.filter((item) => item.status === "PENDING").reduce((sum, item) => sum + item.amountCents, 0), byType: [...byType].map(([type, amountCents]) => ({ type, amountCents })), byUser: [...byUser.values()].sort((a, b) => b.amountCents - a.amountCents) };
    }
    assertPeriod(startAt, endAt) {
        if (Number.isNaN(startAt.getTime()) || Number.isNaN(endAt.getTime()) || startAt >= endAt)
            throw new common_1.BadRequestException("班次开始时间必须早于结束时间");
        if (endAt.getTime() - startAt.getTime() > 24 * 60 * 60 * 1000)
            throw new common_1.BadRequestException("单个班次不能超过 24 小时");
    }
    async assertShiftAvailable(userId, startAt, endAt, excludeId) {
        const conflict = await this.prisma.workShift.findFirst({ where: { userId, status: "SCHEDULED", ...(excludeId ? { id: { not: excludeId } } : {}), startAt: { lt: endAt }, endAt: { gt: startAt } } });
        if (conflict)
            throw new common_1.BadRequestException("员工在该时段已有班次");
    }
    sessionSlot(session) {
        return { id: session.id, code: session.code, scriptName: session.script.name, roomName: session.room.name, startAt: session.startAt, endAt: session.expectedEndAt };
    }
    audit(user, action, entityType, entityId, payload) {
        return this.prisma.auditLog.create({ data: { userId: user.id, action, entityType, entityId, payload: payload ? JSON.stringify(payload) : undefined } });
    }
};
exports.WorkforceService = WorkforceService;
exports.WorkforceService = WorkforceService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], WorkforceService);
//# sourceMappingURL=workforce.service.js.map