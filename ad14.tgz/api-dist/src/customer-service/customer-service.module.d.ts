export declare class CustomerServiceModule {
}
