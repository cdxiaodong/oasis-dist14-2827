"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomerServiceService = void 0;
const common_1 = require("@nestjs/common");
const user_session_1 = require("../common/user-session");
const assets_1 = require("../common/assets");
const prisma_service_1 = require("../prisma/prisma.service");
const REVIEW_SOURCES = new Set(["PLATFORM", "CLIENT", "CUSTOMER_SERVICE"]);
const CONTACT_TYPES = new Set(["PHONE", "WECHAT", "INSTORE"]);
const FOLLOWUP_RESULTS = new Set(["SATISFIED", "DISSATISFIED", "PENDING"]);
let CustomerServiceService = class CustomerServiceService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    scope(user, storeId) {
        if (user_session_1.GLOBAL_ROLES.has(user.role))
            return storeId;
        if (!user.storeId)
            throw new common_1.ForbiddenException("账号未绑定门店");
        if (storeId && storeId !== user.storeId)
            throw new common_1.ForbiddenException("无权访问其他门店");
        return user.storeId;
    }
    requireStore(user, storeId) {
        const scoped = this.scope(user, storeId);
        if (!scoped)
            throw new common_1.BadRequestException("请选择门店");
        return scoped;
    }
    canWrite(user) {
        if (!["CUSTOMER_SERVICE", "MANAGER", "HEADQUARTERS"].includes(user.role)) {
            throw new common_1.ForbiddenException("仅客服、店长或总部可维护好评与回访");
        }
    }
    dateOnly(value) {
        const date = new Date(`${value.slice(0, 10)}T00:00:00.000+08:00`);
        if (Number.isNaN(date.getTime()))
            throw new common_1.BadRequestException("日期格式不正确");
        return date;
    }
    range(from, to) {
        const now = new Date();
        const start = from ? this.dateOnly(from) : new Date(now.getFullYear(), now.getMonth(), 1);
        const toStart = to ? this.dateOnly(to) : new Date(now.getFullYear(), now.getMonth() + 1, 0);
        const end = new Date(toStart.getTime() + 24 * 60 * 60 * 1000);
        if (start >= end)
            throw new common_1.BadRequestException("开始日期必须早于结束日期");
        return { start, end };
    }
    reviews(user, query) {
        const scoped = this.scope(user, query.storeId);
        const { start, end } = this.range(query.from, query.to);
        const where = { reviewedAt: { gte: start, lt: end } };
        if (scoped)
            where.storeId = scoped;
        if (query.source && REVIEW_SOURCES.has(query.source))
            where.source = query.source;
        if (query.premium === "true")
            where.isPremium = true;
        if (query.premium === "quality")
            where.isQuality = true;
        return this.prisma.review.findMany({
            where,
            include: {
                store: { select: { id: true, name: true } },
                handledBy: { select: { id: true, name: true } },
            },
            orderBy: { reviewedAt: "desc" },
            take: 500,
        });
    }
    reviewStats(user, query) {
        const scoped = this.scope(user, query.storeId);
        const { start, end } = this.range(query.from, query.to);
        const where = { reviewedAt: { gte: start, lt: end }, ...(scoped ? { storeId: scoped } : {}) };
        return Promise.all([
            this.prisma.review.count({ where: { ...where, source: "PLATFORM" } }),
            this.prisma.review.count({ where: { ...where, source: "CLIENT" } }),
            this.prisma.review.count({ where: { ...where, source: "CUSTOMER_SERVICE" } }),
            this.prisma.review.count({ where: { ...where, isPremium: true } }),
            this.prisma.review.count({ where: { ...where, isQuality: true } }),
            this.prisma.review.count({ where }),
        ]).then(([platform, client, cs, premium, quality, total]) => ({
            platform,
            client,
            customerService: cs,
            premium,
            quality,
            total,
        }));
    }
    async createReview(user, dto) {
        this.canWrite(user);
        const storeId = this.requireStore(user, dto.storeId);
        if (!REVIEW_SOURCES.has(dto.source))
            throw new common_1.BadRequestException("好评来源不正确");
        const proofUrl = dto.proofUrl ? (0, assets_1.protectedImageUrl)(dto.proofUrl, "好评截图") : null;
        const rating = dto.rating ?? 5;
        if (rating < 1 || rating > 5)
            throw new common_1.BadRequestException("评分需在 1-5 之间");
        if (dto.sessionId) {
            const session = await this.prisma.gameSession.findUnique({ where: { id: dto.sessionId } });
            if (!session || (session.storeId !== storeId))
                throw new common_1.BadRequestException("关联车次不存在或不属于本门店");
        }
        return this.prisma.review.create({
            data: {
                storeId,
                source: dto.source,
                channel: dto.channel?.trim() || null,
                reviewerName: dto.reviewerName?.trim() || null,
                content: dto.content?.trim() || null,
                rating,
                isPremium: Boolean(dto.isPremium),
                isQuality: Boolean(dto.isQuality),
                proofUrl,
                sessionId: dto.sessionId || null,
                reviewedAt: this.dateOnly(dto.reviewedAt),
                handledById: user.id,
            },
            include: { store: { select: { id: true, name: true } }, handledBy: { select: { id: true, name: true } } },
        });
    }
    async updateReview(user, id, dto) {
        this.canWrite(user);
        const existing = await this.prisma.review.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("好评记录不存在");
        if (!(0, user_session_1.canAccessStore)(user, existing.storeId))
            throw new common_1.ForbiddenException("无权操作");
        const data = {};
        if (dto.channel !== undefined)
            data.channel = dto.channel?.trim() || null;
        if (dto.reviewerName !== undefined)
            data.reviewerName = dto.reviewerName?.trim() || null;
        if (dto.content !== undefined)
            data.content = dto.content?.trim() || null;
        if (dto.rating !== undefined) {
            if (dto.rating < 1 || dto.rating > 5)
                throw new common_1.BadRequestException("评分需在 1-5 之间");
            data.rating = dto.rating;
        }
        if (dto.isPremium !== undefined)
            data.isPremium = Boolean(dto.isPremium);
        if (dto.isQuality !== undefined)
            data.isQuality = Boolean(dto.isQuality);
        if (dto.proofUrl !== undefined)
            data.proofUrl = dto.proofUrl === null ? null : (0, assets_1.protectedImageUrl)(dto.proofUrl, "好评截图");
        if (dto.reviewedAt !== undefined)
            data.reviewedAt = this.dateOnly(dto.reviewedAt);
        return this.prisma.review.update({ where: { id }, data, include: { store: { select: { id: true, name: true } }, handledBy: { select: { id: true, name: true } } } });
    }
    async deleteReview(user, id) {
        this.canWrite(user);
        const existing = await this.prisma.review.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("好评记录不存在");
        if (!(0, user_session_1.canAccessStore)(user, existing.storeId))
            throw new common_1.ForbiddenException("无权操作");
        await this.prisma.review.delete({ where: { id } });
        return { ok: true };
    }
    followUps(user, query) {
        const scoped = this.scope(user, query.storeId);
        const { start, end } = this.range(query.from, query.to);
        const where = { contactedAt: { gte: start, lt: end } };
        if (scoped)
            where.storeId = scoped;
        if (query.result && FOLLOWUP_RESULTS.has(query.result))
            where.result = query.result;
        return this.prisma.customerFollowUp.findMany({
            where,
            include: {
                store: { select: { id: true, name: true } },
                handledBy: { select: { id: true, name: true } },
            },
            orderBy: { contactedAt: "desc" },
            take: 500,
        });
    }
    async createFollowUp(user, dto) {
        this.canWrite(user);
        const storeId = this.requireStore(user, dto.storeId);
        const contactType = dto.contactType && CONTACT_TYPES.has(dto.contactType) ? dto.contactType : "PHONE";
        const result = dto.result && FOLLOWUP_RESULTS.has(dto.result) ? dto.result : "SATISFIED";
        if (dto.sessionId) {
            const session = await this.prisma.gameSession.findUnique({ where: { id: dto.sessionId } });
            if (!session || session.storeId !== storeId)
                throw new common_1.BadRequestException("关联车次不存在或不属于本门店");
        }
        return this.prisma.customerFollowUp.create({
            data: {
                storeId,
                customerName: dto.customerName.trim(),
                contact: dto.contact?.trim() || null,
                contactType,
                result,
                content: dto.content.trim(),
                sessionId: dto.sessionId || null,
                contactedAt: this.dateOnly(dto.contactedAt),
                nextFollowUpAt: dto.nextFollowUpAt ? this.dateOnly(dto.nextFollowUpAt) : null,
                handledById: user.id,
            },
            include: { store: { select: { id: true, name: true } }, handledBy: { select: { id: true, name: true } } },
        });
    }
    async updateFollowUp(user, id, dto) {
        this.canWrite(user);
        const existing = await this.prisma.customerFollowUp.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("回访记录不存在");
        if (!(0, user_session_1.canAccessStore)(user, existing.storeId))
            throw new common_1.ForbiddenException("无权操作");
        const data = {};
        if (dto.customerName !== undefined)
            data.customerName = dto.customerName.trim();
        if (dto.contact !== undefined)
            data.contact = dto.contact?.trim() || null;
        if (dto.contactType !== undefined && CONTACT_TYPES.has(dto.contactType))
            data.contactType = dto.contactType;
        if (dto.result !== undefined && FOLLOWUP_RESULTS.has(dto.result))
            data.result = dto.result;
        if (dto.content !== undefined)
            data.content = dto.content.trim();
        if (dto.nextFollowUpAt !== undefined)
            data.nextFollowUpAt = dto.nextFollowUpAt ? this.dateOnly(dto.nextFollowUpAt) : null;
        return this.prisma.customerFollowUp.update({ where: { id }, data, include: { store: { select: { id: true, name: true } }, handledBy: { select: { id: true, name: true } } } });
    }
    async deleteFollowUp(user, id) {
        this.canWrite(user);
        const existing = await this.prisma.customerFollowUp.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("回访记录不存在");
        if (!(0, user_session_1.canAccessStore)(user, existing.storeId))
            throw new common_1.ForbiddenException("无权操作");
        await this.prisma.customerFollowUp.delete({ where: { id } });
        return { ok: true };
    }
    recentSessions(user, storeId) {
        const scoped = this.requireStore(user, storeId);
        const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        return this.prisma.gameSession.findMany({
            where: { storeId: scoped, startAt: { gte: since } },
            select: {
                id: true,
                startAt: true,
                state: true,
                script: { select: { id: true, name: true } },
                host: { select: { id: true, name: true } },
            },
            orderBy: { startAt: "desc" },
            take: 100,
        });
    }
};
exports.CustomerServiceService = CustomerServiceService;
exports.CustomerServiceService = CustomerServiceService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], CustomerServiceService);
//# sourceMappingURL=customer-service.service.js.map