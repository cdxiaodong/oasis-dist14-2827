export declare function distanceMeters(from: {
    latitude: number;
    longitude: number;
}, to: {
    latitude: number;
    longitude: number;
}): number;
export declare function evaluateGeofence(input: {
    storeLatitude: number | null;
    storeLongitude: number | null;
    latitude: number;
    longitude: number;
    accuracyMeters: number;
    radiusMeters: number;
    maxAccuracyMeters: number;
}): {
    eligible: boolean;
    reasonCode: "STORE_NOT_CONFIGURED";
    reason: string;
    distanceMeters: null;
} | {
    eligible: boolean;
    reasonCode: "LOW_ACCURACY";
    reason: string;
    distanceMeters: number;
} | {
    eligible: boolean;
    reasonCode: "OUTSIDE_GEOFENCE";
    reason: string;
    distanceMeters: number;
} | {
    eligible: boolean;
    reasonCode: "INSIDE_GEOFENCE";
    reason: string;
    distanceMeters: number;
};
