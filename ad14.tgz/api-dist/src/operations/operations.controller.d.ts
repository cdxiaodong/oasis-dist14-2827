import type { UserSession } from "../common/user-session";
import { OperationsService } from "./operations.service";
declare class AttendanceDto {
    type: string;
    latitude: number;
    longitude: number;
    accuracyMeters: number;
    capturedAt: string;
    photoUrl?: string;
    exceptionReason?: string;
    note?: string;
}
declare class AttendanceLocationDto {
    latitude: number;
    longitude: number;
    accuracyMeters: number;
}
declare class AttendanceSettingsDto {
    storeId: string;
    latitude?: number;
    longitude?: number;
    accuracyMeters?: number;
    radiusMeters?: number;
    maxAccuracyMeters?: number;
}
declare class AttendanceActionDto {
    action: string;
    comment?: string;
}
declare class ReimbursementDto {
    category: string;
    amountCents: number;
    description: string;
    receiptUrl?: string;
}
declare class ReimbursementActionDto {
    action: string;
    comment?: string;
}
declare class ReimbursementRuleDto {
    storeId: string;
    category: string;
    maxAmountCents: number;
    enabled: boolean;
    note?: string;
}
export declare class OperationsController {
    private readonly operations;
    constructor(operations: OperationsService);
    attendance(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        type: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        latitude: number | null;
        longitude: number | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        userId: string;
        photoUrl: string | null;
        location: string | null;
        accuracyMeters: number | null;
        distanceMeters: number | null;
        locationStatus: string;
        exceptionReason: string | null;
        capturedAt: Date | null;
    })[]>;
    createAttendance(user: UserSession, dto: AttendanceDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        type: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        latitude: number | null;
        longitude: number | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        userId: string;
        photoUrl: string | null;
        location: string | null;
        accuracyMeters: number | null;
        distanceMeters: number | null;
        locationStatus: string;
        exceptionReason: string | null;
        capturedAt: Date | null;
    }>;
    checkAttendanceLocation(user: UserSession, dto: AttendanceLocationDto): Promise<{
        storeId: string;
        storeName: string;
        radiusMeters: number;
        maxAccuracyMeters: number;
        eligible: boolean;
        reasonCode: "STORE_NOT_CONFIGURED";
        reason: string;
        distanceMeters: null;
    } | {
        storeId: string;
        storeName: string;
        radiusMeters: number;
        maxAccuracyMeters: number;
        eligible: boolean;
        reasonCode: "LOW_ACCURACY";
        reason: string;
        distanceMeters: number;
    } | {
        storeId: string;
        storeName: string;
        radiusMeters: number;
        maxAccuracyMeters: number;
        eligible: boolean;
        reasonCode: "OUTSIDE_GEOFENCE";
        reason: string;
        distanceMeters: number;
    } | {
        storeId: string;
        storeName: string;
        radiusMeters: number;
        maxAccuracyMeters: number;
        eligible: boolean;
        reasonCode: "INSIDE_GEOFENCE";
        reason: string;
        distanceMeters: number;
    }>;
    attendanceSettings(user: UserSession, storeId?: string): Promise<{
        configured: boolean;
        id: string;
        name: string;
        latitude: number | null;
        longitude: number | null;
        attendanceRadiusMeters: number;
        attendanceMaxAccuracyMeters: number;
        attendanceLocationUpdatedAt: Date | null;
    }[]>;
    saveAttendanceSettings(user: UserSession, dto: AttendanceSettingsDto): Promise<{
        configured: boolean;
        id: string;
        name: string;
        latitude: number | null;
        longitude: number | null;
        attendanceRadiusMeters: number;
        attendanceMaxAccuracyMeters: number;
        attendanceLocationUpdatedAt: Date | null;
    }>;
    actionAttendance(user: UserSession, id: string, dto: AttendanceActionDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        type: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        latitude: number | null;
        longitude: number | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        userId: string;
        photoUrl: string | null;
        location: string | null;
        accuracyMeters: number | null;
        distanceMeters: number | null;
        locationStatus: string;
        exceptionReason: string | null;
        capturedAt: Date | null;
    }>;
    reimbursements(user: UserSession, storeId?: string, category?: string, from?: string, to?: string, userId?: string, search?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        description: string;
        category: string;
        userId: string;
        receiptUrl: string | null;
        managerComment: string | null;
        financeComment: string | null;
    })[]>;
    createReimbursement(user: UserSession, dto: ReimbursementDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        description: string;
        category: string;
        userId: string;
        receiptUrl: string | null;
        managerComment: string | null;
        financeComment: string | null;
    }>;
    action(user: UserSession, id: string, dto: ReimbursementActionDto): Promise<{
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        description: string;
        category: string;
        userId: string;
        receiptUrl: string | null;
        managerComment: string | null;
        financeComment: string | null;
    }>;
    rules(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        category: string;
        maxAmountCents: number;
        enabled: boolean;
    })[]>;
    saveRule(user: UserSession, dto: ReimbursementRuleDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        category: string;
        maxAmountCents: number;
        enabled: boolean;
    }>;
}
export {};
