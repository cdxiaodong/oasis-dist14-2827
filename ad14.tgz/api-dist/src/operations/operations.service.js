"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationsService = void 0;
const common_1 = require("@nestjs/common");
const user_session_1 = require("../common/user-session");
const prisma_service_1 = require("../prisma/prisma.service");
const geofence_1 = require("./geofence");
const assets_1 = require("../common/assets");
let OperationsService = class OperationsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    scope(user, storeId) {
        if (user_session_1.GLOBAL_ROLES.has(user.role))
            return storeId;
        if (!user.storeId)
            throw new common_1.ForbiddenException("账号未绑定门店");
        if (storeId && storeId !== user.storeId)
            throw new common_1.ForbiddenException("无权访问其他门店");
        return user.storeId;
    }
    attendance(user, storeId) {
        const scoped = this.scope(user, storeId);
        const canViewTeam = ["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role);
        return this.prisma.attendance.findMany({
            where: { ...(scoped ? { storeId: scoped } : {}), ...(!canViewTeam ? { userId: user.id } : {}) },
            include: { user: { select: { id: true, name: true, role: true } }, store: true, reviewedBy: { select: { id: true, name: true } } },
            orderBy: { createdAt: "desc" },
            take: 300,
        });
    }
    attendanceSettings(user, storeId) {
        const scoped = this.scope(user, storeId);
        return this.prisma.store.findMany({
            where: scoped ? { id: scoped } : { active: true },
            select: { id: true, name: true, latitude: true, longitude: true, attendanceRadiusMeters: true, attendanceMaxAccuracyMeters: true, attendanceLocationUpdatedAt: true },
            orderBy: { name: "asc" },
        }).then((stores) => stores.map((store) => ({ ...store, configured: store.latitude !== null && store.longitude !== null })));
    }
    async saveAttendanceSettings(user, data) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以设置打卡范围");
        const storeId = this.scope(user, data.storeId);
        if (!storeId)
            throw new common_1.BadRequestException("请选择门店");
        const store = await this.prisma.store.findUnique({ where: { id: storeId } });
        if (!store)
            throw new common_1.NotFoundException("门店不存在");
        const hasLatitude = data.latitude !== undefined;
        const hasLongitude = data.longitude !== undefined;
        if (hasLatitude !== hasLongitude)
            throw new common_1.BadRequestException("门店经纬度必须同时提交");
        const maxAccuracy = data.maxAccuracyMeters ?? store.attendanceMaxAccuracyMeters;
        if (hasLatitude && data.accuracyMeters === undefined)
            throw new common_1.BadRequestException("设置门店位置时必须提交定位精度");
        if (hasLatitude && data.accuracyMeters > maxAccuracy)
            throw new common_1.BadRequestException(`当前定位精度不足，请在精度优于 ${maxAccuracy} 米时重试`);
        const updated = await this.prisma.store.update({
            where: { id: storeId },
            data: {
                ...(hasLatitude ? { latitude: data.latitude, longitude: data.longitude, attendanceLocationUpdatedAt: new Date() } : {}),
                ...(data.radiusMeters !== undefined ? { attendanceRadiusMeters: data.radiusMeters } : {}),
                ...(data.maxAccuracyMeters !== undefined ? { attendanceMaxAccuracyMeters: data.maxAccuracyMeters } : {}),
            },
            select: { id: true, name: true, latitude: true, longitude: true, attendanceRadiusMeters: true, attendanceMaxAccuracyMeters: true, attendanceLocationUpdatedAt: true },
        });
        await this.audit(user, "SAVE_ATTENDANCE_SETTINGS", "Store", storeId, { locationUpdated: hasLatitude, radiusMeters: updated.attendanceRadiusMeters, maxAccuracyMeters: updated.attendanceMaxAccuracyMeters });
        return { ...updated, configured: updated.latitude !== null && updated.longitude !== null };
    }
    async checkAttendanceLocation(user, data) {
        if (!user.storeId)
            throw new common_1.BadRequestException("总部和财务账号不能进行门店打卡");
        const store = await this.prisma.store.findUnique({ where: { id: user.storeId } });
        if (!store || !store.active)
            throw new common_1.BadRequestException("所属门店不存在或已停用");
        const result = (0, geofence_1.evaluateGeofence)({
            storeLatitude: store.latitude,
            storeLongitude: store.longitude,
            latitude: data.latitude,
            longitude: data.longitude,
            accuracyMeters: data.accuracyMeters,
            radiusMeters: store.attendanceRadiusMeters,
            maxAccuracyMeters: store.attendanceMaxAccuracyMeters,
        });
        return { ...result, storeId: store.id, storeName: store.name, radiusMeters: store.attendanceRadiusMeters, maxAccuracyMeters: store.attendanceMaxAccuracyMeters };
    }
    async createAttendance(user, data) {
        if (!user.storeId)
            throw new common_1.BadRequestException("总部和财务账号不能进行门店打卡");
        const capturedAt = new Date(data.capturedAt);
        const age = Date.now() - capturedAt.getTime();
        if (Number.isNaN(capturedAt.getTime()) || age > 5 * 60_000 || age < -60_000)
            throw new common_1.BadRequestException("定位信息已过期，请重新定位后打卡");
        if (!data.photoUrl)
            throw new common_1.BadRequestException("打卡必须上传当日工装现场照片");
        await this.assertAttendanceSequence(user.id, data.type);
        const geofence = await this.checkAttendanceLocation(user, data);
        const isException = !geofence.eligible;
        if (isException && (!data.exceptionReason?.trim() || data.exceptionReason.trim().length < 4)) {
            throw new common_1.BadRequestException(`${geofence.reason}；异常打卡需填写至少 4 个字的原因`);
        }
        if (isException && !data.photoUrl)
            throw new common_1.BadRequestException(`${geofence.reason}；异常打卡必须上传现场照片`);
        const attendance = await this.prisma.attendance.create({
            data: {
                type: data.type,
                photoUrl: (0, assets_1.protectedImageUrl)(data.photoUrl, "打卡照片"),
                note: data.note,
                latitude: data.latitude,
                longitude: data.longitude,
                accuracyMeters: data.accuracyMeters,
                distanceMeters: geofence.distanceMeters,
                location: geofence.distanceMeters === null ? geofence.reason : `距门店约 ${geofence.distanceMeters} 米`,
                locationStatus: geofence.reasonCode,
                reviewStatus: isException ? "PENDING" : "NOT_REQUIRED",
                exceptionReason: isException ? data.exceptionReason?.trim() : undefined,
                capturedAt,
                userId: user.id,
                storeId: user.storeId,
            },
            include: { user: { select: { id: true, name: true, role: true } }, store: true, reviewedBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, "CREATE_ATTENDANCE", "Attendance", attendance.id, { type: data.type, storeId: user.storeId, locationStatus: attendance.locationStatus, reviewStatus: attendance.reviewStatus, distanceMeters: attendance.distanceMeters });
        return attendance;
    }
    async actionAttendance(user, id, action, comment) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以审核异常打卡");
        const attendance = await this.prisma.attendance.findUnique({ where: { id } });
        if (!attendance)
            throw new common_1.NotFoundException("打卡记录不存在");
        if (!(0, user_session_1.canAccessStore)(user, attendance.storeId))
            throw new common_1.ForbiddenException("无权审核其他门店打卡");
        if (attendance.reviewStatus !== "PENDING")
            throw new common_1.BadRequestException("该打卡记录无需审核或已经处理");
        if (action === "REJECT" && !comment?.trim())
            throw new common_1.BadRequestException("驳回时必须填写原因");
        const updated = await this.prisma.attendance.update({
            where: { id },
            data: { reviewStatus: action === "APPROVE" ? "APPROVED" : "REJECTED", reviewComment: comment?.trim(), reviewedAt: new Date(), reviewedById: user.id },
            include: { user: { select: { id: true, name: true, role: true } }, store: true, reviewedBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, `ATTENDANCE_${action}`, "Attendance", id, { comment });
        return updated;
    }
    reimbursements(user, query) {
        const scoped = this.scope(user, query.storeId);
        const canViewTeam = ["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role);
        const from = query.from ? new Date(`${query.from.slice(0, 10)}T00:00:00+08:00`) : undefined;
        const toStart = query.to ? new Date(`${query.to.slice(0, 10)}T00:00:00+08:00`) : undefined;
        const to = toStart ? new Date(toStart.getTime() + 86_400_000) : undefined;
        const search = query.search?.trim();
        return this.prisma.reimbursement.findMany({
            where: {
                ...(scoped ? { storeId: scoped } : {}),
                ...(!canViewTeam ? { userId: user.id } : query.userId ? { userId: query.userId } : {}),
                ...(query.category ? { category: query.category } : {}),
                ...(from || to ? { createdAt: { ...(from ? { gte: from } : {}), ...(to ? { lt: to } : {}) } } : {}),
                ...(search ? { OR: [{ category: { contains: search } }, { description: { contains: search } }, { user: { name: { contains: search } } }] } : {}),
            },
            include: { user: { select: { id: true, name: true, role: true } }, store: true },
            orderBy: { createdAt: "desc" },
        });
    }
    async createReimbursement(user, data) {
        if (!user.storeId)
            throw new common_1.BadRequestException("总部和财务账号请使用门店员工账号提交报销");
        if (!data.description.trim())
            throw new common_1.BadRequestException("请填写报销说明");
        if (!data.receiptUrl)
            throw new common_1.BadRequestException("请上传报销凭证");
        const receiptUrl = (0, assets_1.protectedImageUrl)(data.receiptUrl, "报销凭证");
        const reimbursement = await this.prisma.reimbursement.create({
            data: { ...data, receiptUrl, status: "PENDING_MANAGER", userId: user.id, storeId: user.storeId },
            include: { user: { select: { id: true, name: true, role: true } }, store: true },
        });
        await this.audit(user, "CREATE_REIMBURSEMENT", "Reimbursement", reimbursement.id, { amountCents: data.amountCents, category: data.category });
        return reimbursement;
    }
    reimbursementRules(user, storeId) {
        const scoped = this.scope(user, storeId);
        return this.prisma.reimbursementRule.findMany({ where: scoped ? { storeId: scoped } : {}, include: { store: true }, orderBy: [{ store: { name: "asc" } }, { category: "asc" }] });
    }
    async saveReimbursementRule(user, data) {
        if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("无权维护报销规则");
        const storeId = this.scope(user, data.storeId);
        if (!storeId)
            throw new common_1.BadRequestException("请选择门店");
        const saved = await this.prisma.reimbursementRule.upsert({ where: { storeId_category: { storeId, category: data.category } }, create: { ...data, storeId }, update: { maxAmountCents: data.maxAmountCents, enabled: data.enabled, note: data.note }, include: { store: true } });
        await this.audit(user, "SAVE_REIMBURSEMENT_RULE", "ReimbursementRule", saved.id, data);
        return saved;
    }
    async actionReimbursement(user, id, action, comment) {
        const item = await this.prisma.reimbursement.findUnique({ where: { id } });
        if (!item)
            throw new common_1.NotFoundException("报销单不存在");
        if (!(0, user_session_1.canAccessStore)(user, item.storeId))
            throw new common_1.ForbiddenException("无权处理该报销单");
        const normalized = action.toUpperCase();
        if (normalized === "MANAGER_APPROVE") {
            if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
                throw new common_1.ForbiddenException("只有店长可以初审");
            if (item.status !== "PENDING_MANAGER")
                throw new common_1.BadRequestException("报销单不在店长审核阶段");
            const updated = await this.prisma.reimbursement.update({ where: { id }, data: { status: "PENDING_FINANCE", managerComment: comment } });
            await this.audit(user, "MANAGER_APPROVE_REIMBURSEMENT", "Reimbursement", id, { comment });
            return updated;
        }
        if (normalized === "FINANCE_APPROVE") {
            if (!["FINANCE", "HEADQUARTERS"].includes(user.role))
                throw new common_1.ForbiddenException("只有财务可以复核");
            if (item.status !== "PENDING_FINANCE")
                throw new common_1.BadRequestException("报销单不在财务审核阶段");
            const updated = await this.prisma.reimbursement.update({ where: { id }, data: { status: "APPROVED", financeComment: comment } });
            await this.audit(user, "FINANCE_APPROVE_REIMBURSEMENT", "Reimbursement", id, { comment });
            return updated;
        }
        if (normalized === "REJECT") {
            if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
                throw new common_1.ForbiddenException("无权驳回报销单");
            const updated = await this.prisma.reimbursement.update({ where: { id }, data: { status: "REJECTED", ...(user.role === "FINANCE" ? { financeComment: comment } : { managerComment: comment }) } });
            await this.audit(user, "REJECT_REIMBURSEMENT", "Reimbursement", id, { comment });
            return updated;
        }
        throw new common_1.BadRequestException("不支持的报销操作");
    }
    async assertAttendanceSequence(userId, type) {
        const now = new Date();
        const china = new Date(now.getTime() + 8 * 60 * 60_000);
        const dayStart = new Date(Date.UTC(china.getUTCFullYear(), china.getUTCMonth(), china.getUTCDate()) - 8 * 60 * 60_000);
        const latest = await this.prisma.attendance.findFirst({
            where: { userId, createdAt: { gte: dayStart }, reviewStatus: { not: "REJECTED" } },
            orderBy: { createdAt: "desc" },
        });
        if (latest && now.getTime() - latest.createdAt.getTime() < 60_000)
            throw new common_1.BadRequestException("一分钟内不能重复打卡");
        if (type === "CLOCK_IN" && latest?.type === "CLOCK_IN")
            throw new common_1.BadRequestException("当前已有未结束的上班记录，请先下班打卡");
        if (type === "CLOCK_OUT" && (!latest || latest.type !== "CLOCK_IN"))
            throw new common_1.BadRequestException("今天没有可对应的上班打卡记录");
    }
    audit(user, action, entityType, entityId, payload) {
        return this.prisma.auditLog.create({
            data: { userId: user.id, action, entityType, entityId, payload: payload ? JSON.stringify(payload) : undefined },
        });
    }
};
exports.OperationsService = OperationsService;
exports.OperationsService = OperationsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], OperationsService);
//# sourceMappingURL=operations.service.js.map