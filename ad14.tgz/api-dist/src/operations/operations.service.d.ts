import { type UserSession } from "../common/user-session";
import { PrismaService } from "../prisma/prisma.service";
export declare class OperationsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private scope;
    attendance(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        type: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        latitude: number | null;
        longitude: number | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        userId: string;
        photoUrl: string | null;
        location: string | null;
        accuracyMeters: number | null;
        distanceMeters: number | null;
        locationStatus: string;
        exceptionReason: string | null;
        capturedAt: Date | null;
    })[]>;
    attendanceSettings(user: UserSession, storeId?: string): Promise<{
        configured: boolean;
        id: string;
        name: string;
        latitude: number | null;
        longitude: number | null;
        attendanceRadiusMeters: number;
        attendanceMaxAccuracyMeters: number;
        attendanceLocationUpdatedAt: Date | null;
    }[]>;
    saveAttendanceSettings(user: UserSession, data: {
        storeId: string;
        latitude?: number;
        longitude?: number;
        accuracyMeters?: number;
        radiusMeters?: number;
        maxAccuracyMeters?: number;
    }): Promise<{
        configured: boolean;
        id: string;
        name: string;
        latitude: number | null;
        longitude: number | null;
        attendanceRadiusMeters: number;
        attendanceMaxAccuracyMeters: number;
        attendanceLocationUpdatedAt: Date | null;
    }>;
    checkAttendanceLocation(user: UserSession, data: {
        latitude: number;
        longitude: number;
        accuracyMeters: number;
    }): Promise<{
        storeId: string;
        storeName: string;
        radiusMeters: number;
        maxAccuracyMeters: number;
        eligible: boolean;
        reasonCode: "STORE_NOT_CONFIGURED";
        reason: string;
        distanceMeters: null;
    } | {
        storeId: string;
        storeName: string;
        radiusMeters: number;
        maxAccuracyMeters: number;
        eligible: boolean;
        reasonCode: "LOW_ACCURACY";
        reason: string;
        distanceMeters: number;
    } | {
        storeId: string;
        storeName: string;
        radiusMeters: number;
        maxAccuracyMeters: number;
        eligible: boolean;
        reasonCode: "OUTSIDE_GEOFENCE";
        reason: string;
        distanceMeters: number;
    } | {
        storeId: string;
        storeName: string;
        radiusMeters: number;
        maxAccuracyMeters: number;
        eligible: boolean;
        reasonCode: "INSIDE_GEOFENCE";
        reason: string;
        distanceMeters: number;
    }>;
    createAttendance(user: UserSession, data: {
        type: string;
        latitude: number;
        longitude: number;
        accuracyMeters: number;
        capturedAt: string;
        photoUrl?: string;
        exceptionReason?: string;
        note?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        type: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        latitude: number | null;
        longitude: number | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        userId: string;
        photoUrl: string | null;
        location: string | null;
        accuracyMeters: number | null;
        distanceMeters: number | null;
        locationStatus: string;
        exceptionReason: string | null;
        capturedAt: Date | null;
    }>;
    actionAttendance(user: UserSession, id: string, action: string, comment?: string): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        type: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        latitude: number | null;
        longitude: number | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        userId: string;
        photoUrl: string | null;
        location: string | null;
        accuracyMeters: number | null;
        distanceMeters: number | null;
        locationStatus: string;
        exceptionReason: string | null;
        capturedAt: Date | null;
    }>;
    reimbursements(user: UserSession, query: {
        storeId?: string;
        category?: string;
        from?: string;
        to?: string;
        userId?: string;
        search?: string;
    }): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        description: string;
        category: string;
        userId: string;
        receiptUrl: string | null;
        managerComment: string | null;
        financeComment: string | null;
    })[]>;
    createReimbursement(user: UserSession, data: {
        category: string;
        amountCents: number;
        description: string;
        receiptUrl?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        description: string;
        category: string;
        userId: string;
        receiptUrl: string | null;
        managerComment: string | null;
        financeComment: string | null;
    }>;
    reimbursementRules(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        category: string;
        maxAmountCents: number;
        enabled: boolean;
    })[]>;
    saveReimbursementRule(user: UserSession, data: {
        storeId: string;
        category: string;
        maxAmountCents: number;
        enabled: boolean;
        note?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        category: string;
        maxAmountCents: number;
        enabled: boolean;
    }>;
    actionReimbursement(user: UserSession, id: string, action: string, comment?: string): Promise<{
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        description: string;
        category: string;
        userId: string;
        receiptUrl: string | null;
        managerComment: string | null;
        financeComment: string | null;
    }>;
    private assertAttendanceSequence;
    private audit;
}
