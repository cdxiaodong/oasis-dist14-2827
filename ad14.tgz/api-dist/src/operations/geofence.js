"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.distanceMeters = distanceMeters;
exports.evaluateGeofence = evaluateGeofence;
const EARTH_RADIUS_METERS = 6_371_000;
const radians = (degrees) => degrees * Math.PI / 180;
function distanceMeters(from, to) {
    const latitudeDelta = radians(to.latitude - from.latitude);
    const longitudeDelta = radians(to.longitude - from.longitude);
    const fromLatitude = radians(from.latitude);
    const toLatitude = radians(to.latitude);
    const haversine = Math.sin(latitudeDelta / 2) ** 2
        + Math.cos(fromLatitude) * Math.cos(toLatitude) * Math.sin(longitudeDelta / 2) ** 2;
    return Math.round(EARTH_RADIUS_METERS * 2 * Math.atan2(Math.sqrt(haversine), Math.sqrt(1 - haversine)));
}
function evaluateGeofence(input) {
    if (input.storeLatitude === null || input.storeLongitude === null) {
        return { eligible: false, reasonCode: "STORE_NOT_CONFIGURED", reason: "门店尚未设置打卡位置", distanceMeters: null };
    }
    const distance = distanceMeters({ latitude: input.storeLatitude, longitude: input.storeLongitude }, { latitude: input.latitude, longitude: input.longitude });
    if (input.accuracyMeters > input.maxAccuracyMeters) {
        return { eligible: false, reasonCode: "LOW_ACCURACY", reason: `定位精度不足（当前约 ${Math.round(input.accuracyMeters)} 米）`, distanceMeters: distance };
    }
    if (distance > input.radiusMeters) {
        return { eligible: false, reasonCode: "OUTSIDE_GEOFENCE", reason: `距离门店约 ${distance} 米，超出 ${input.radiusMeters} 米打卡范围`, distanceMeters: distance };
    }
    return { eligible: true, reasonCode: "INSIDE_GEOFENCE", reason: "已进入门店打卡范围", distanceMeters: distance };
}
//# sourceMappingURL=geofence.js.map