import type { UserSession } from "../common/user-session";
import { StaffDevelopmentService } from "./staff-development.service";
declare class QualificationDto {
    userId: string;
    scriptId: string;
    status: string;
    score?: number;
    note?: string;
    expiresAt?: string;
}
declare class ViolationDto {
    employeeId: string;
    category: string;
    severity: string;
    description: string;
    occurredAt: string;
    evidenceUrl?: string;
}
declare class ViolationActionDto {
    action: string;
    comment?: string;
}
export declare class StaffDevelopmentController {
    private readonly service;
    constructor(service: StaffDevelopmentService);
    qualifications(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        user: {
            id: string;
            name: string;
            role: string;
        };
        script: {
            store: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            };
        } & {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        assessor: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        note: string | null;
        createdAt: Date;
        updatedAt: Date;
        scriptId: string;
        status: string;
        userId: string;
        score: number | null;
        assessedAt: Date | null;
        expiresAt: Date | null;
        assessorId: string | null;
    })[]>;
    saveQualification(user: UserSession, dto: QualificationDto): Promise<{
        user: {
            id: string;
            name: string;
            role: string;
        };
        script: {
            store: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            };
        } & {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        assessor: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        note: string | null;
        createdAt: Date;
        updatedAt: Date;
        scriptId: string;
        status: string;
        userId: string;
        score: number | null;
        assessedAt: Date | null;
        expiresAt: Date | null;
        assessorId: string | null;
    }>;
    violations(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
        employee: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        description: string;
        category: string;
        severity: string;
        evidenceUrl: string | null;
        occurredAt: Date;
        appealText: string | null;
        appealedAt: Date | null;
        employeeId: string;
    })[]>;
    createViolation(user: UserSession, dto: ViolationDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        employee: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        description: string;
        category: string;
        severity: string;
        evidenceUrl: string | null;
        occurredAt: Date;
        appealText: string | null;
        appealedAt: Date | null;
        employeeId: string;
    }>;
    actionViolation(user: UserSession, id: string, dto: ViolationActionDto): Promise<{
        id: string;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        description: string;
        category: string;
        severity: string;
        evidenceUrl: string | null;
        occurredAt: Date;
        appealText: string | null;
        appealedAt: Date | null;
        employeeId: string;
    }>;
}
export {};
