"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StaffDevelopmentService = void 0;
const common_1 = require("@nestjs/common");
const user_session_1 = require("../common/user-session");
const prisma_service_1 = require("../prisma/prisma.service");
let StaffDevelopmentService = class StaffDevelopmentService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    scope(user, storeId) {
        if (user.role === "CUSTOMER_SERVICE")
            throw new common_1.ForbiddenException("客服账号不开放培训与违规模块");
        if (user_session_1.GLOBAL_ROLES.has(user.role))
            return storeId;
        if (!user.storeId)
            throw new common_1.ForbiddenException("账号未绑定门店");
        if (storeId && storeId !== user.storeId)
            throw new common_1.ForbiddenException("无权访问其他门店");
        return user.storeId;
    }
    requireManager(user) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以维护培训与违规记录");
    }
    qualifications(user, storeId) {
        const scoped = this.scope(user, storeId);
        const ownOnly = !["MANAGER", "HEADQUARTERS", "FINANCE"].includes(user.role);
        return this.prisma.scriptQualification.findMany({
            where: { ...(scoped ? { script: { storeId: scoped } } : {}), ...(ownOnly ? { userId: user.id } : {}) },
            include: { user: { select: { id: true, name: true, role: true } }, script: { include: { store: true } }, assessor: { select: { id: true, name: true } } },
            orderBy: [{ status: "asc" }, { updatedAt: "desc" }],
        });
    }
    async saveQualification(user, data) {
        this.requireManager(user);
        const [employee, script] = await Promise.all([this.prisma.user.findUnique({ where: { id: data.userId } }), this.prisma.script.findUnique({ where: { id: data.scriptId } })]);
        if (!employee || !script)
            throw new common_1.NotFoundException("员工或剧本不存在");
        if (employee.storeId !== script.storeId)
            throw new common_1.BadRequestException("员工与剧本必须属于同一门店");
        if (!(0, user_session_1.canAccessStore)(user, script.storeId))
            throw new common_1.ForbiddenException("无权维护该门店过本记录");
        const saved = await this.prisma.scriptQualification.upsert({
            where: { userId_scriptId: { userId: data.userId, scriptId: data.scriptId } },
            create: { ...data, assessorId: user.id, assessedAt: new Date(), expiresAt: data.expiresAt ? new Date(data.expiresAt) : undefined },
            update: { status: data.status, score: data.score, note: data.note, assessorId: user.id, assessedAt: new Date(), expiresAt: data.expiresAt ? new Date(data.expiresAt) : null },
            include: { user: { select: { id: true, name: true, role: true } }, script: { include: { store: true } }, assessor: { select: { id: true, name: true } } },
        });
        await this.audit(user, "SAVE_SCRIPT_QUALIFICATION", "ScriptQualification", saved.id, data);
        return saved;
    }
    violations(user, storeId) {
        const scoped = this.scope(user, storeId);
        const ownOnly = !["MANAGER", "HEADQUARTERS", "FINANCE"].includes(user.role);
        return this.prisma.violationRecord.findMany({
            where: { ...(scoped ? { storeId: scoped } : {}), ...(ownOnly ? { employeeId: user.id } : {}) },
            include: { store: true, employee: { select: { id: true, name: true, role: true } }, createdBy: { select: { id: true, name: true } }, reviewedBy: { select: { id: true, name: true } } },
            orderBy: { occurredAt: "desc" },
        });
    }
    async createViolation(user, data) {
        this.requireManager(user);
        const employee = await this.prisma.user.findUnique({ where: { id: data.employeeId } });
        if (!employee?.storeId)
            throw new common_1.BadRequestException("员工未绑定门店");
        if (!(0, user_session_1.canAccessStore)(user, employee.storeId))
            throw new common_1.ForbiddenException("无权登记其他门店员工违规");
        const record = await this.prisma.violationRecord.create({
            data: { ...data, occurredAt: new Date(data.occurredAt), storeId: employee.storeId, createdById: user.id },
            include: { store: true, employee: { select: { id: true, name: true, role: true } }, createdBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, "CREATE_VIOLATION", "ViolationRecord", record.id, data);
        return record;
    }
    async actionViolation(user, id, action, comment) {
        const record = await this.prisma.violationRecord.findUnique({ where: { id } });
        if (!record)
            throw new common_1.NotFoundException("违规记录不存在");
        if (!(0, user_session_1.canAccessStore)(user, record.storeId))
            throw new common_1.ForbiddenException("无权处理该记录");
        if (action === "APPEAL") {
            if (record.employeeId !== user.id)
                throw new common_1.ForbiddenException("只有当事员工可以申诉");
            if (record.status !== "APPROVED")
                throw new common_1.BadRequestException("只有已确认记录可以申诉");
            const appealed = await this.prisma.violationRecord.update({ where: { id }, data: { status: "APPEALED", appealText: comment || "申请复核", appealedAt: new Date() } });
            await this.audit(user, "APPEAL_VIOLATION", "ViolationRecord", id, { comment });
            return appealed;
        }
        this.requireManager(user);
        const allowed = record.status === "PENDING_REVIEW" ? ["APPROVE", "REJECT"] : record.status === "APPEALED" ? ["UPHOLD", "DISMISS"] : [];
        if (!allowed.includes(action))
            throw new common_1.BadRequestException("当前状态不能执行该操作");
        const status = { APPROVE: "APPROVED", REJECT: "REJECTED", UPHOLD: "UPHELD", DISMISS: "DISMISSED" }[action];
        const updated = await this.prisma.violationRecord.update({ where: { id }, data: { status, reviewComment: comment, reviewedById: user.id, reviewedAt: new Date() }, include: { store: true, employee: { select: { id: true, name: true, role: true } }, reviewedBy: { select: { id: true, name: true } } } });
        await this.audit(user, `VIOLATION_${action}`, "ViolationRecord", id, { comment });
        return updated;
    }
    audit(user, action, entityType, entityId, payload) {
        return this.prisma.auditLog.create({ data: { userId: user.id, action, entityType, entityId, payload: payload ? JSON.stringify(payload) : undefined } });
    }
};
exports.StaffDevelopmentService = StaffDevelopmentService;
exports.StaffDevelopmentService = StaffDevelopmentService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], StaffDevelopmentService);
//# sourceMappingURL=staff-development.service.js.map