export declare function protectedImageUrl(value: string, label?: string): string;
