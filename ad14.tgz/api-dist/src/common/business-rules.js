"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.END_MATERIAL_LABELS = exports.OPTIONAL_END_MATERIAL_LABELS = exports.REQUIRED_END_MATERIAL_LABELS = exports.ACTIVITY_TYPE_NAMES = exports.ACTIVITY_TYPE_DEFINITIONS = void 0;
exports.ACTIVITY_TYPE_DEFINITIONS = [
    { name: "大学生活动", defaultDiscountCents: 1000, sortOrder: 10 },
    { name: "夜场活动", defaultDiscountCents: 1000, sortOrder: 20 },
    { name: "好评活动", defaultDiscountCents: 0, sortOrder: 30 },
    { name: "早鸟票", defaultDiscountCents: 0, sortOrder: 40 },
    { name: "其它", defaultDiscountCents: 0, sortOrder: 50 },
];
exports.ACTIVITY_TYPE_NAMES = exports.ACTIVITY_TYPE_DEFINITIONS.map((item) => item.name);
exports.REQUIRED_END_MATERIAL_LABELS = [
    "桌面全景照片",
    "垃圾桶照片",
    "空调关闭照片",
    "剧本线索整理照片",
    "剧本入库照片",
    "遥控器归位照片",
    "房间关灯照片",
    "门牌或门灯还原照片",
];
exports.OPTIONAL_END_MATERIAL_LABELS = ["道具归还照片", "其它"];
exports.END_MATERIAL_LABELS = [...exports.REQUIRED_END_MATERIAL_LABELS, ...exports.OPTIONAL_END_MATERIAL_LABELS];
//# sourceMappingURL=business-rules.js.map