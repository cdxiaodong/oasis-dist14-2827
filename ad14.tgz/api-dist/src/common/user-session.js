"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GLOBAL_ROLES = void 0;
exports.canAccessStore = canAccessStore;
exports.GLOBAL_ROLES = new Set(["HEADQUARTERS", "FINANCE"]);
function canAccessStore(user, storeId) {
    return exports.GLOBAL_ROLES.has(user.role) || user.storeId === storeId;
}
//# sourceMappingURL=user-session.js.map