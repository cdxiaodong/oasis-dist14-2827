"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const core_1 = require("@nestjs/core");
const auth_guard_1 = require("./auth/auth.guard");
const auth_module_1 = require("./auth/auth.module");
const business_module_1 = require("./business/business.module");
const customer_service_module_1 = require("./customer-service/customer-service.module");
const catalog_module_1 = require("./catalog/catalog.module");
const dashboard_module_1 = require("./dashboard/dashboard.module");
const members_module_1 = require("./members/members.module");
const operations_module_1 = require("./operations/operations.module");
const prisma_module_1 = require("./prisma/prisma.module");
const sessions_module_1 = require("./sessions/sessions.module");
const session_join_module_1 = require("./session-join/session-join.module");
const staff_development_module_1 = require("./staff-development/staff-development.module");
const system_module_1 = require("./system/system.module");
const uploads_module_1 = require("./uploads/uploads.module");
const workforce_module_1 = require("./workforce/workforce.module");
const health_controller_1 = require("./health.controller");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({ isGlobal: true }),
            prisma_module_1.PrismaModule,
            auth_module_1.AuthModule,
            business_module_1.BusinessModule,
            customer_service_module_1.CustomerServiceModule,
            catalog_module_1.CatalogModule,
            sessions_module_1.SessionsModule,
            session_join_module_1.SessionJoinModule,
            members_module_1.MembersModule,
            operations_module_1.OperationsModule,
            dashboard_module_1.DashboardModule,
            uploads_module_1.UploadsModule,
            system_module_1.SystemModule,
            workforce_module_1.WorkforceModule,
            staff_development_module_1.StaffDevelopmentModule,
        ],
        controllers: [health_controller_1.HealthController],
        providers: [{ provide: core_1.APP_GUARD, useClass: auth_guard_1.AuthGuard }],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map