import { StreamableFile } from "@nestjs/common";
import { SessionJoinService } from "./session-join.service";
import { JoinPlayerDto } from "./session-join.dto";
export declare class SessionJoinController {
    private readonly join;
    constructor(join: SessionJoinService);
    summary(token: string): Promise<{
        code: string;
        scriptName: string;
        storeName: string;
        roomName: string;
        startAt: Date;
        closed: boolean;
        joinEnabled: boolean;
        joinable: boolean;
        playerCount: number;
        maxPlayerCount: number;
        remainingSeats: number;
    }>;
    register(token: string, dto: JoinPlayerDto): Promise<{
        playerId: string;
        duplicated: boolean;
        verified: boolean;
    }>;
    qrcode(token: string): Promise<StreamableFile>;
}
