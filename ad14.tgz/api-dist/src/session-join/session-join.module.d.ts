export declare class SessionJoinModule {
}
