"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionJoinController = void 0;
const common_1 = require("@nestjs/common");
const public_decorator_1 = require("../auth/public.decorator");
const session_join_service_1 = require("./session-join.service");
const session_join_dto_1 = require("./session-join.dto");
let SessionJoinController = class SessionJoinController {
    join;
    constructor(join) {
        this.join = join;
    }
    summary(token) {
        return this.join.summary(token);
    }
    register(token, dto) {
        return this.join.register(token, dto);
    }
    async qrcode(token) {
        return new common_1.StreamableFile(await this.join.qrcode(token), { type: "image/png" });
    }
};
exports.SessionJoinController = SessionJoinController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(":token"),
    __param(0, (0, common_1.Param)("token")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SessionJoinController.prototype, "summary", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)(":token/players"),
    __param(0, (0, common_1.Param)("token")),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, session_join_dto_1.JoinPlayerDto]),
    __metadata("design:returntype", void 0)
], SessionJoinController.prototype, "register", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(":token/qrcode.png"),
    (0, common_1.Header)("Cache-Control", "private, max-age=300"),
    __param(0, (0, common_1.Param)("token")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SessionJoinController.prototype, "qrcode", null);
exports.SessionJoinController = SessionJoinController = __decorate([
    (0, common_1.Controller)("session-join"),
    __metadata("design:paramtypes", [session_join_service_1.SessionJoinService])
], SessionJoinController);
//# sourceMappingURL=session-join.controller.js.map