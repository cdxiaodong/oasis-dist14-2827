"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadsService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const promises_1 = require("node:fs/promises");
const node_crypto_1 = require("node:crypto");
const node_path_1 = require("node:path");
const MIME_EXTENSIONS = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
};
let UploadsService = class UploadsService {
    config;
    constructor(config) {
        this.config = config;
    }
    async saveImage(dataUrl, originalName) {
        const matched = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
        if (!matched)
            throw new common_1.BadRequestException("仅支持 JPG、PNG 或 WebP 图片");
        const buffer = Buffer.from(matched[2], "base64");
        if (!buffer.length || buffer.length > 5 * 1024 * 1024)
            throw new common_1.BadRequestException("图片大小必须在 5MB 以内");
        const uploadDir = (0, node_path_1.resolve)(this.config.get("UPLOAD_DIR", (0, node_path_1.resolve)(process.cwd(), "uploads")));
        await (0, promises_1.mkdir)(uploadDir, { recursive: true });
        const filename = `${Date.now()}-${(0, node_crypto_1.randomUUID)()}.${MIME_EXTENSIONS[matched[1]]}`;
        await (0, promises_1.writeFile)((0, node_path_1.resolve)(uploadDir, filename), buffer, { flag: "wx" });
        return { url: `/api/uploads/files/${filename}`, filename, originalName: originalName ?? null, size: buffer.length };
    }
    async readImage(filename) {
        if (!/^\d+-[0-9a-f-]+\.(?:jpg|png|webp)$/.test(filename))
            throw new common_1.BadRequestException("图片地址不正确");
        const uploadDir = (0, node_path_1.resolve)(this.config.get("UPLOAD_DIR", (0, node_path_1.resolve)(process.cwd(), "uploads")));
        try {
            return await (0, promises_1.readFile)((0, node_path_1.resolve)(uploadDir, filename));
        }
        catch {
            throw new common_1.BadRequestException("图片不存在");
        }
    }
};
exports.UploadsService = UploadsService;
exports.UploadsService = UploadsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], UploadsService);
//# sourceMappingURL=uploads.service.js.map