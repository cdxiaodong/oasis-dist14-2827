import { StreamableFile } from "@nestjs/common";
import { UploadsService } from "./uploads.service";
declare class ImageUploadDto {
    dataUrl: string;
    filename?: string;
}
export declare class UploadsController {
    private readonly uploads;
    constructor(uploads: UploadsService);
    image(dto: ImageUploadDto): Promise<{
        url: string;
        filename: string;
        originalName: string | null;
        size: number;
    }>;
    file(filename: string): Promise<StreamableFile>;
}
export {};
