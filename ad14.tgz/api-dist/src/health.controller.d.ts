export declare class HealthController {
    health(): {
        status: string;
        service: string;
        time: string;
    };
}
