import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { GLOBAL_ROLES, canAccessStore, type UserSession } from "../common/user-session";
import { PrismaService } from "../prisma/prisma.service";
import { protectedImageUrl } from "../common/assets";

@Injectable()
export class MembersService {
  constructor(private readonly prisma: PrismaService) {}

  private scope(user: UserSession, storeId?: string) {
    if (user.role === "CUSTOMER_SERVICE") throw new ForbiddenException("客服账号无权访问会员资金数据");
    if (GLOBAL_ROLES.has(user.role)) return storeId;
    if (!user.storeId) throw new ForbiddenException("账号未绑定门店");
    if (storeId && storeId !== user.storeId) throw new ForbiddenException("无权访问其他门店会员");
    return user.storeId;
  }

  list(user: UserSession, storeId?: string, search?: string) {
    const scoped = this.scope(user, storeId);
    const keyword = search?.trim();
    const searchWhere = keyword ? { OR: [{ name: { contains: keyword } }, { phone: { contains: keyword } }] } : {};
    if (!["HEADQUARTERS", "FINANCE", "MANAGER", "DM", "ASSISTANT", "NPC", "STAFF"].includes(user.role)) throw new ForbiddenException("当前岗位无权访问会员数据");
    if (user.role === "DM") {
      // 主持人：本店正式会员 + 待审核申请（含自己与同事提交的，方便跟进开卡状态）
      return this.prisma.member.findMany({
        where: { storeId: scoped!, status: { in: ["ACTIVE", "PENDING"] }, ...searchWhere },
        select: { id: true, name: true, phone: true, status: true, tier: true, balanceCents: true, pendingCreditCents: true, storeId: true, store: true, openedById: true },
        orderBy: [{ status: "desc" }, { name: "asc" }],
      }).then((items) => items.map((item) => ({ ...item, phone: `****${item.phone.slice(-4)}`, ledgers: [] })));
    }
    if (["ASSISTANT", "NPC", "STAFF"].includes(user.role)) {
      // 其他一线员工：只看自己提交的开卡申请及审核状态
      return this.prisma.member.findMany({
        where: { storeId: scoped!, openedById: user.id, ...searchWhere },
        select: { id: true, name: true, phone: true, status: true, tier: true, balanceCents: true, pendingCreditCents: true, storeId: true, store: true, openedById: true },
        orderBy: { createdAt: "desc" },
      }).then((items) => items.map((item) => ({ ...item, phone: `****${item.phone.slice(-4)}`, ledgers: [] })));
    }
    return this.prisma.member.findMany({
      where: { ...(scoped ? { storeId: scoped } : {}), ...searchWhere },
      include: { store: true, openedBy: { select: { id: true, name: true } }, ledgers: { include: { operator: { select: { id: true, name: true } } }, orderBy: { createdAt: "desc" } } },
      orderBy: { createdAt: "desc" },
    });
  }

  async create(user: UserSession, data: { storeId: string; name: string; phone: string; initialAmountCents: number; paymentProofUrl?: string; source?: string }) {
    if (!["HEADQUARTERS", "MANAGER", "DM"].includes(user.role)) throw new ForbiddenException("只有主持人、店长或总部可以提交开卡申请");
    if (!data.paymentProofUrl) throw new BadRequestException("开卡申请必须上传付款凭证");
    const storeId = this.scope(user, data.storeId);
    if (!storeId) throw new BadRequestException("请选择门店");
    return this.prisma.member.create({
      data: {
        storeId,
        name: data.name,
        phone: data.phone,
        pendingCreditCents: data.initialAmountCents,
        paymentProofUrl: protectedImageUrl(data.paymentProofUrl, "开卡付款凭证"),
        source: data.source,
        openedById: user.id,
      },
      include: { store: true, ledgers: true },
    });
  }

  async approve(user: UserSession, id: string) {
    if (!["MANAGER", "HEADQUARTERS"].includes(user.role)) throw new ForbiddenException("只有店长或总部可以审核会员");
    return this.prisma.$transaction(async (tx) => {
      const member = await tx.member.findUnique({ where: { id } });
      if (!member) throw new NotFoundException("会员不存在");
      if (!canAccessStore(user, member.storeId)) throw new ForbiddenException("无权审核该会员");
      if (member.status !== "PENDING") throw new BadRequestException("该会员已经处理");
      const balance = member.balanceCents + member.pendingCreditCents;
      await tx.memberLedger.create({
        data: { memberId: id, operatorId: user.id, type: "RECHARGE", amountCents: member.pendingCreditCents, balanceAfterCents: balance, note: "开卡审核通过" },
      });
      const updated = await tx.member.update({ where: { id }, data: { status: "ACTIVE", balanceCents: balance, pendingCreditCents: 0 }, include: { ledgers: true, store: true } });
      await tx.auditLog.create({ data: { userId: user.id, action: "APPROVE_MEMBER", entityType: "Member", entityId: id, payload: JSON.stringify({ amountCents: member.pendingCreditCents }) } });
      return updated;
    });
  }

  async consume(user: UserSession, id: string, amountCents: number, note?: string) {
    if (!["MANAGER", "HEADQUARTERS"].includes(user.role)) throw new ForbiddenException("会员余额只能通过车次扣卡或由店长调整");
    if (amountCents <= 0) throw new BadRequestException("消费金额必须大于 0");
    return this.prisma.$transaction(async (tx) => {
      const member = await tx.member.findUnique({ where: { id } });
      if (!member) throw new NotFoundException("会员不存在");
      if (!canAccessStore(user, member.storeId)) throw new ForbiddenException("无权操作该会员");
      if (member.status !== "ACTIVE") throw new BadRequestException("会员未激活");
      if (member.balanceCents < amountCents) throw new BadRequestException("会员余额不足");
      const balance = member.balanceCents - amountCents;
      await tx.memberLedger.create({ data: { memberId: id, operatorId: user.id, type: "CONSUME", amountCents: -amountCents, balanceAfterCents: balance, note } });
      await tx.auditLog.create({ data: { userId: user.id, action: "CONSUME_MEMBER_BALANCE", entityType: "Member", entityId: id, payload: JSON.stringify({ amountCents, note }) } });
      return tx.member.update({ where: { id }, data: { balanceCents: balance }, include: { ledgers: { orderBy: { createdAt: "desc" } }, store: true } });
    });
  }

  async adjust(user: UserSession, id: string, type: string, amountCents: number, note: string) {
    if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role)) throw new ForbiddenException("只有店长、财务或总部可以调整会员余额");
    if (amountCents <= 0) throw new BadRequestException("金额必须大于 0");
    const positive = ["RECHARGE", "ADJUST_INCREASE"].includes(type);
    if (!positive && !["REFUND", "ADJUST_DECREASE"].includes(type)) throw new BadRequestException("不支持的余额变动类型");
    return this.prisma.$transaction(async (tx) => {
      const member = await tx.member.findUnique({ where: { id } });
      if (!member) throw new NotFoundException("会员不存在");
      if (!canAccessStore(user, member.storeId)) throw new ForbiddenException("无权操作该会员");
      if (member.status !== "ACTIVE") throw new BadRequestException("会员未激活");
      const signedAmount = positive ? amountCents : -amountCents;
      const balance = member.balanceCents + signedAmount;
      if (balance < 0) throw new BadRequestException("会员余额不足");
      await tx.memberLedger.create({ data: { memberId: id, operatorId: user.id, type, amountCents: signedAmount, balanceAfterCents: balance, note } });
      await tx.auditLog.create({ data: { userId: user.id, action: `MEMBER_${type}`, entityType: "Member", entityId: id, payload: JSON.stringify({ amountCents, note }) } });
      return tx.member.update({
        where: { id }, data: { balanceCents: balance },
        include: { store: true, ledgers: { include: { operator: { select: { id: true, name: true } } }, orderBy: { createdAt: "desc" } } },
      });
    });
  }

  async updateTier(user: UserSession, id: string, tier: string) {
    if (!["MANAGER", "HEADQUARTERS"].includes(user.role)) throw new ForbiddenException("只有店长或总部可以调整会员等级");
    const member = await this.prisma.member.findUnique({ where: { id } });
    if (!member) throw new NotFoundException("会员不存在");
    if (!canAccessStore(user, member.storeId)) throw new ForbiddenException("无权操作该会员");
    const updated = await this.prisma.member.update({ where: { id }, data: { tier }, include: { store: true, openedBy: { select: { id: true, name: true } }, ledgers: true } });
    await this.prisma.auditLog.create({ data: { userId: user.id, action: "UPDATE_MEMBER_TIER", entityType: "Member", entityId: id, payload: JSON.stringify({ from: member.tier, to: tier }) } }); return updated;
  }

  async rankings(user: UserSession, query: { storeId?: string; from?: string; to?: string }) {
    const storeId = this.scope(user, query.storeId);
    const now = new Date();
    const from = query.from ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(query.from) ? `${query.from}T00:00:00+08:00` : query.from) : new Date(now.getFullYear(), now.getMonth(), 1);
    const to = query.to ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(query.to) ? `${query.to}T00:00:00+08:00` : query.to) : new Date(now.getFullYear(), now.getMonth() + 1, 1);
    if (query.to && /^\d{4}-\d{2}-\d{2}$/.test(query.to)) to.setDate(to.getDate() + 1);
    const ledgers = await this.prisma.memberLedger.findMany({ where: { type: { in: ["RECHARGE", "ADJUST_INCREASE"] }, createdAt: { gte: from, lt: to }, member: storeId ? { storeId } : {} }, include: { operator: { select: { id: true, name: true } }, member: { select: { id: true, name: true, storeId: true } } } });
    const recharge = new Map<string, { userId: string; name: string; amountCents: number; count: number }>();
    for (const item of ledgers) if (item.operator) { const row = recharge.get(item.operator.id) ?? { userId: item.operator.id, name: item.operator.name, amountCents: 0, count: 0 }; row.amountCents += item.amountCents; row.count += 1; recharge.set(item.operator.id, row); }
    const members = await this.prisma.member.findMany({ where: { ...(storeId ? { storeId } : {}), createdAt: { gte: from, lt: to }, openedById: { not: null } }, include: { openedBy: { select: { id: true, name: true } } } });
    const openers = new Map<string, { userId: string; name: string; count: number }>();
    for (const member of members) if (member.openedBy) { const row = openers.get(member.openedBy.id) ?? { userId: member.openedBy.id, name: member.openedBy.name, count: 0 }; row.count += 1; openers.set(member.openedBy.id, row); }
    return { rechargeRanking: [...recharge.values()].sort((a, b) => b.amountCents - a.amountCents), openerRanking: [...openers.values()].sort((a, b) => b.count - a.count) };
  }
}
